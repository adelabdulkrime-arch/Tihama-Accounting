import { supabase } from '../lib/supabase.js';

function ready() {
  if (!supabase) throw new Error('Supabase غير مهيأ.');
}

async function fetchAllPages(buildQuery, pageSize = 500) {
  const rows = [];
  for (let offset = 0; ; offset += pageSize) {
    const { data, error } = await buildQuery().range(offset, offset + pageSize - 1);
    if (error) throw error;
    rows.push(...(data ?? []));
    if (!data || data.length < pageSize) return rows;
  }
}

export async function getLedgerAccounts() {
  ready();
  const { data, error } = await supabase
    .from('ledger_accounts')
    .select('id,account_code,account_name,account_type,currency,is_active,is_cash,category_key,institution_name,external_account_number,alternate_reference,opening_balance,created_at')
    .order('account_code');
  if (error) throw error;
  return data ?? [];
}

export async function setOpeningBalances(balances, entryDate, description) {
  ready();
  const { data, error } = await supabase.rpc('set_opening_balances', {
    p_balances: balances,
    p_entry_date: entryDate,
    p_description: description,
  });
  if (error) throw error;
  return data;
}

export async function createLedgerAccount(input) {
  ready();
  const { data, error } = await supabase.rpc('create_ledger_account', {
    p_account_code: input.accountCode.trim(),
    p_account_name: input.accountName.trim(),
    p_account_type: input.accountType,
    p_currency: input.currency,
    p_is_cash: Boolean(input.isCash),
    p_category_key: input.categoryKey?.trim() || null,
  });
  if (error) throw error;
  return data;
}

export async function postVoucher(recordId) {
  ready();
  const { data, error } = await supabase.rpc('post_voucher', { p_record_id: recordId });
  if (error) throw error;
  return data;
}

export async function reverseVoucher(recordId, reason) {
  ready();
  const { data, error } = await supabase.rpc('reverse_voucher', {
    p_record_id: recordId,
    p_reason: reason,
  });
  if (error) throw error;
  return data;
}

export async function getLedgerSnapshot() {
  ready();
  const entries = await fetchAllPages(() => supabase
    .from('journal_entries')
    .select('id,entry_number,entry_date,description,currency,entry_kind,status,source_record_id,reversal_of,created_at')
    .order('entry_number', { ascending: false }));
  if (!entries?.length) return { entries: [], lines: [] };
  const ids = entries.map((entry) => entry.id);
  const lines = await fetchAllPages(() => supabase
    .from('journal_lines')
    .select('id,entry_id,line_number,description,debit,credit,currency,account_id')
    .in('entry_id', ids)
    .order('entry_id')
    .order('line_number'));
  const accountIds = [...new Set((lines ?? []).map((line) => line.account_id))];
  let accounts = [];
  if (accountIds.length) {
    accounts = await fetchAllPages(() => supabase
      .from('ledger_accounts')
      .select('id,account_code,account_name,account_type,currency')
      .in('id', accountIds)
      .order('account_code'));
  }
  const accountMap = new Map(accounts.map((account) => [account.id, account]));
  return {
    entries: entries.map((entry) => ({ ...entry, lines: (lines ?? []).filter((line) => line.entry_id === entry.id).map((line) => ({ ...line, account: accountMap.get(line.account_id) })) })),
    lines: (lines ?? []).map((line) => ({ ...line, account: accountMap.get(line.account_id) })),
  };
}

export async function getAccountingPeriods() {
  ready();
  const { data, error } = await supabase
    .from('accounting_periods')
    .select('id,period_start,period_end,status,close_reason,closed_by,closed_at,reopened_by,reopened_at,reopen_reason')
    .order('period_start', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function closeAccountingPeriod(start, end, reason) {
  ready();
  const { data, error } = await supabase.rpc('close_accounting_period', {
    p_start: start, p_end: end, p_reason: reason,
  });
  if (error) throw error;
  return data;
}

export async function reopenAccountingPeriod(start, end, reason) {
  ready();
  const { data, error } = await supabase.rpc('reopen_accounting_period', {
    p_start: start, p_end: end, p_reason: reason,
  });
  if (error) throw error;
  return data;
}

export async function getAuditEvents(limit = 50, offset = 0) {
  ready();
  const { data, error } = await supabase.rpc('get_audit_events', { p_limit: limit, p_offset: offset });
  if (error) throw error;
  return data ?? [];
}
