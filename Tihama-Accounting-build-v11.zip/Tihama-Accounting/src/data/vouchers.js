import { listRecords, createRecord, watchCollection } from './records.js';
import { validateVoucher } from './voucher-validation.js';
export { validateVoucher } from './voucher-validation.js';

export const VOUCHER_TYPES = {
  RV: 'سند قبض',
  PV: 'سند صرف',
  TR: 'تحويل داخلي',
  JV: 'قيد يومية',
  ST: 'تسوية',
};

const today = () => new Date().toISOString().slice(0, 10);
const money = (value) => Number(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const clean = (value) => String(value ?? '').trim();

export function createVoucherNumber(type) {
  const date = today().replaceAll('-', '');
  const suffix = crypto.randomUUID().replaceAll('-', '').slice(0, 6).toUpperCase();
  return `${type}-${date}-${suffix}`;
}


export async function saveDraft(input, member) {
  const errors = validateVoucher(input);
  if (errors.length) throw new Error(errors.join(' '));
  if (!member?.user_id || !member?.is_active) throw new Error('لا توجد جلسة مستخدم نشطة.');
  if (!['admin', 'editor'].includes(member.role)) throw new Error('صلاحيتك لا تسمح بإنشاء السندات.');
  const number = input.number || createVoucherNumber(input.type);
  const payload = {
    number,
    type: input.type,
    date: input.date,
    party: clean(input.party),
    category: clean(input.category),
    currency: input.currency,
    amount: Number(input.amount),
    account: clean(input.account),
    fromAccount: clean(input.fromAccount),
    toAccount: clean(input.toAccount),
    exchangeRate: Number(input.exchangeRate) > 0 ? Number(input.exchangeRate) : 1,
    paymentMethod: clean(input.paymentMethod),
    reference: clean(input.reference),
    description: clean(input.description),
    notes: clean(input.notes),
    ...(input.type === 'JV' ? { lines: input.lines.map((line) => ({
      account: clean(line.account),
      debit: Number(line.debit || 0),
      credit: Number(line.credit || 0),
      description: clean(line.description),
      currency: input.currency,
    })) } : {}),
    status: 'draft',
    createdBy: member.user_id,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    schemaVersion: 1,
  };
  await createRecord('vouchers', number, payload);
  return payload;
}

export async function getVouchers() {
  return listRecords('vouchers');
}

export function watchVouchers(onChange, onError) {
  return watchCollection('vouchers', onChange, onError);
}

export function renderVoucherRows(vouchers, canApprove = false) {
  if (!vouchers.length) return '<tr><td colspan="8" class="empty">لا توجد سندات مسجلة بعد.</td></tr>';
  return vouchers.map((v) => `<tr>
    <td dir="ltr">${escapeHtml(v.number || v.id)}</td>
    <td>${escapeHtml(v.date)}</td>
    <td>${escapeHtml(VOUCHER_TYPES[v.type] || v.type)}</td>
    <td>${escapeHtml(v.party || (v.type === 'TR' ? `${v.fromAccount} ← ${v.toAccount}` : '—'))}</td>
    <td>${money(v.amount)} ${escapeHtml(v.currency)}</td>
    <td><span class="status status-${escapeHtml(v.status)}">${v.status === 'draft' ? 'مسودة' : v.status === 'approved' ? 'معتمد' : 'ملغي'}</span></td>
    <td>${escapeHtml(v.description)}</td>
    <td>${canApprove && v.status === 'draft' ? `<button class="small-action approve-action" data-action="approve" data-id="${escapeHtml(v.id || v.number)}">اعتماد وترحيل</button>` : canApprove && v.status === 'approved' ? `<button class="small-action reverse-action" data-action="reverse" data-id="${escapeHtml(v.id || v.number)}">إلغاء بقيد عكسي</button>` : '—'}</td>
  </tr>`).join('');
}

export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
