/**
 * Read-only journal projection for approved voucher records.
 * This module deliberately does not post, approve, mutate balances, or write audit data.
 * Final posting must move to a single database transaction/RPC guarded by server-side roles.
 */
const TYPES = new Set(['RV', 'PV', 'TR', 'JV']);
const text = (value) => String(value ?? '').trim();
const amount = (value) => {
  const n = value === null || value === undefined || value === '' ? 0 : Number(value);
  if (!Number.isFinite(n) || n < 0) throw new Error('قيمة محاسبية غير صالحة.');
  return Math.round((n + Number.EPSILON) * 100) / 100;
};

function add(lines, voucher, account, debit, credit, currency = voucher.currency) {
  const dr = amount(debit);
  const cr = amount(credit);
  if (!text(account)) throw new Error(`الحساب غير محدد في السند ${voucher.number || voucher.id || ''}.`);
  if (dr > 0 && cr > 0) throw new Error('لا يجوز أن يكون السطر مديناً ودائناً في الوقت نفسه.');
  if (dr === 0 && cr === 0) return;
  lines.push({
    date: voucher.date,
    voucherNumber: voucher.number || voucher.id,
    voucherType: voucher.type,
    description: text(voucher.description),
    account: text(account),
    currency: text(currency),
    debit: dr,
    credit: cr,
  });
}

export function projectVoucherToJournal(voucher) {
  if (!voucher || voucher.status !== 'approved') return [];
  if (!TYPES.has(voucher.type)) return [];
  const lines = [];
  const total = amount(voucher.amount);
  if (total <= 0) throw new Error('مبلغ السند المعتمد يجب أن يكون أكبر من صفر.');

  if (voucher.type === 'RV') {
    add(lines, voucher, `نقدية / ${text(voucher.account)}`, total, 0);
    const creditAccount = voucher.isAdvance
      ? 'سلف وعهد الموظفين'
      : `إيراد / ${text(voucher.category) || 'إيرادات متنوعة'}`;
    add(lines, voucher, creditAccount, 0, total);
  } else if (voucher.type === 'PV') {
    const debitAccount = voucher.isAdvance
      ? 'سلف وعهد الموظفين'
      : `مصروف / ${text(voucher.category) || 'مصروفات متنوعة'}`;
    add(lines, voucher, debitAccount, total, 0);
    add(lines, voucher, `نقدية / ${text(voucher.account)}`, 0, total);
  } else if (voucher.type === 'TR') {
    if (text(voucher.fromAccount) === text(voucher.toAccount)) {
      throw new Error('حسابا التحويل الداخلي يجب أن يكونا مختلفين.');
    }
    add(lines, voucher, `نقدية / ${text(voucher.toAccount)}`, total, 0);
    add(lines, voucher, `نقدية / ${text(voucher.fromAccount)}`, 0, total);
  } else if (voucher.type === 'JV') {
    const entries = Array.isArray(voucher.lines) ? voucher.lines : [];
    if (entries.length < 2) throw new Error('القيد اليومي يحتاج إلى سطرين على الأقل.');
    for (const line of entries) add(lines, voucher, line.account, line.debit, line.credit, line.currency || voucher.currency);
  }

  assertBalanced(lines, voucher.number || voucher.id);
  return lines;
}

export function assertBalanced(lines, reference = '') {
  const totals = new Map();
  for (const line of lines) {
    const currency = text(line.currency);
    if (!currency) throw new Error('عملة القيد غير محددة.');
    const current = totals.get(currency) || { debit: 0, credit: 0 };
    current.debit += amount(line.debit);
    current.credit += amount(line.credit);
    totals.set(currency, current);
  }
  for (const [currency, total] of totals) {
    if (Math.abs(total.debit - total.credit) > 0.01) {
      throw new Error(`القيد ${reference} غير متوازن بعملة ${currency}.`);
    }
  }
  return true;
}

export function buildJournal(vouchers = []) {
  return vouchers
    .filter((voucher) => voucher?.status === 'approved')
    .flatMap(projectVoucherToJournal)
    .sort((a, b) => a.date.localeCompare(b.date) || a.voucherNumber.localeCompare(b.voucherNumber));
}

export function buildTrialBalance(journal = []) {
  const totals = new Map();
  for (const line of journal) {
    const key = `${text(line.account)}\u0000${text(line.currency)}`;
    const row = totals.get(key) || { account: text(line.account), currency: text(line.currency), debit: 0, credit: 0 };
    row.debit += amount(line.debit);
    row.credit += amount(line.credit);
    totals.set(key, row);
  }
  return [...totals.values()]
    .map((row) => ({
      ...row,
      debit: amount(row.debit),
      credit: amount(row.credit),
      netDebit: amount(Math.max(row.debit - row.credit, 0)),
      netCredit: amount(Math.max(row.credit - row.debit, 0)),
    }))
    .sort((a, b) => a.account.localeCompare(b.account) || a.currency.localeCompare(b.currency));
}

export function journalTotals(journal = []) {
  const totals = new Map();
  for (const line of journal) {
    const row = totals.get(line.currency) || { currency: line.currency, debit: 0, credit: 0 };
    row.debit += amount(line.debit);
    row.credit += amount(line.credit);
    totals.set(line.currency, row);
  }
  return [...totals.values()].map((row) => ({ ...row, debit: amount(row.debit), credit: amount(row.credit), balanced: Math.abs(row.debit - row.credit) <= 0.01 }));
}
