import { supabase } from '../lib/supabase.js';

// Supported business collections only. Security-sensitive `keys` and client-written
// `audit` data are intentionally excluded until their dedicated server-side design exists.
const COLLECTIONS = new Set([
  'vouchers', 'emps', 'sal', 'adv', 'cus', 'fa', 'close', 'par', 'reg', 'settings',
]);

function assertReady(collection) {
  if (!supabase) throw new Error('Supabase is not configured.');
  if (!COLLECTIONS.has(collection)) throw new Error(`Unsupported collection: ${collection}`);
}

export async function listRecords(collection) {
  assertReady(collection);
  const { data, error } = await supabase
    .from('app_records')
    .select('record_id,payload,created_at,updated_at')
    .eq('collection', collection)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map((row) => ({ ...row.payload, id: row.record_id, _createdAt: row.created_at, _updatedAt: row.updated_at }));
}

export async function getRecord(collection, recordId) {
  assertReady(collection);
  if (!recordId) throw new Error('recordId is required.');
  const { data, error } = await supabase
    .from('app_records')
    .select('record_id,payload,created_at,updated_at')
    .eq('collection', collection)
    .eq('record_id', String(recordId))
    .maybeSingle();
  if (error) throw error;
  return data ? { ...data.payload, id: data.record_id, _createdAt: data.created_at, _updatedAt: data.updated_at } : null;
}


export async function createRecord(collection, recordId, payload) {
  assertReady(collection);
  if (!recordId) throw new Error('recordId is required.');
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('payload must be an object.');
  const { data, error } = await supabase
    .from('app_records')
    .insert({ collection, record_id: String(recordId), payload })
    .select('record_id,payload,created_at,updated_at')
    .single();
  if (error) throw error;
  return { ...data.payload, id: data.record_id, _createdAt: data.created_at, _updatedAt: data.updated_at };
}

export async function saveRecord(collection, recordId, payload) {
  assertReady(collection);
  if (!recordId) throw new Error('recordId is required.');
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('payload must be an object.');
  const { data, error } = await supabase
    .from('app_records')
    .upsert({ collection, record_id: String(recordId), payload, updated_at: new Date().toISOString() }, { onConflict: 'collection,record_id' })
    .select('record_id,payload,created_at,updated_at')
    .single();
  if (error) throw error;
  return { ...data.payload, id: data.record_id, _createdAt: data.created_at, _updatedAt: data.updated_at };
}

export async function deleteRecord(collection, recordId) {
  assertReady(collection);
  if (!recordId) throw new Error('recordId is required.');
  const { error, count } = await supabase
    .from('app_records')
    .delete({ count: 'exact' })
    .eq('collection', collection)
    .eq('record_id', String(recordId));
  if (error) throw error;
  return count ?? 0;
}

export function watchCollection(collection, onChange, onError = () => {}) {
  assertReady(collection);
  if (typeof onChange !== 'function') throw new Error('onChange callback is required.');
  const channel = supabase
    .channel(`records:${collection}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'app_records', filter: `collection=eq.${collection}` }, async () => {
      try { onChange(await listRecords(collection)); } catch (error) { onError(error); }
    })
    .subscribe((status, error) => { if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') onError(error ?? new Error(status)); });
  listRecords(collection).then(onChange).catch(onError);
  return () => supabase.removeChannel(channel);
}
