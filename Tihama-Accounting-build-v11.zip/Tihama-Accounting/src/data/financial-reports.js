const money = (value) => Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
const isPosted = (entry) => entry?.status === 'posted' || entry?.status === 'reversed';
const inRange = (date, from, to) => (!from || date >= from) && (!to || date <= to);
const normalSide = (accountType) => ['liability', 'equity', 'revenue'].includes(accountType) ? 'credit' : 'debit';

function flattenPostedEntries(entries = []) {
  return entries
    .filter(isPosted)
    .flatMap((entry) => (entry.lines || []).map((line) => ({
      ...line,
      entryId: entry.id,
      entryNumber: entry.entry_number,
      entryDate: entry.entry_date,
      entryDescription: entry.description,
      entryKind: entry.entry_kind,
      entryStatus: entry.status,
    })))
    .sort((a, b) => String(a.entryDate).localeCompare(String(b.entryDate))
      || Number(a.entryNumber || 0) - Number(b.entryNumber || 0)
      || Number(a.line_number || 0) - Number(b.line_number || 0));
}

function accountBalance(lines, account, currency, throughDate) {
  const side = normalSide(account.account_type);
  let debit = 0;
  let credit = 0;
  for (const line of lines) {
    if (line.account_id !== account.id || line.currency !== currency || (throughDate && line.entryDate > throughDate)) continue;
    debit += Number(line.debit || 0);
    credit += Number(line.credit || 0);
  }
  return money(side === 'debit' ? debit - credit : credit - debit);
}

export function buildTrialBalance(accounts = [], entries = [], asOf = '') {
  const lines = flattenPostedEntries(entries);
  const currencies = [...new Set([
    ...accounts.map((account) => account.currency),
    ...lines.filter((line) => !asOf || line.entryDate <= asOf).map((line) => line.currency),
  ].filter(Boolean))].sort();
  const rows = [];
  for (const currency of currencies) {
    for (const account of accounts.filter((item) => item.currency === currency)) {
      const balance = accountBalance(lines, account, currency, asOf);
      if (Math.abs(balance) < 0.005) continue;
      const side = normalSide(account.account_type);
      rows.push({
        accountId: account.id,
        accountCode: account.account_code,
        accountName: account.account_name,
        accountType: account.account_type,
        currency,
        debit: side === 'debit' ? Math.max(balance, 0) : Math.max(-balance, 0),
        credit: side === 'credit' ? Math.max(balance, 0) : Math.max(-balance, 0),
        balance,
      });
    }
  }
  return {
    rows,
    totals: currencies.map((currency) => {
      const selected = rows.filter((row) => row.currency === currency);
      return {
        currency,
        debit: money(selected.reduce((sum, row) => sum + row.debit, 0)),
        credit: money(selected.reduce((sum, row) => sum + row.credit, 0)),
      };
    }),
  };
}

export function buildIncomeStatement(accounts = [], entries = [], from = '', to = '', currencyFilter = '') {
  const lines = flattenPostedEntries(entries).filter((line) => inRange(line.entryDate, from, to)
    && (!currencyFilter || line.currency === currencyFilter));
  const map = new Map();
  for (const line of lines) {
    const account = line.account;
    if (!account || !['revenue', 'expense'].includes(account.account_type)) continue;
    const key = `${account.id}|${line.currency}`;
    const row = map.get(key) || { accountId: account.id, accountCode: account.account_code, accountName: account.account_name, accountType: account.account_type, currency: line.currency, amount: 0 };
    row.amount += account.account_type === 'revenue'
      ? Number(line.credit || 0) - Number(line.debit || 0)
      : Number(line.debit || 0) - Number(line.credit || 0);
    map.set(key, row);
  }
  const rows = [...map.values()].map((row) => ({ ...row, amount: money(row.amount) }))
    .filter((row) => Math.abs(row.amount) >= 0.005)
    .sort((a, b) => a.currency.localeCompare(b.currency) || a.accountCode.localeCompare(b.accountCode));
  const currencies = [...new Set(rows.map((row) => row.currency))].sort();
  return {
    rows,
    totals: currencies.map((currency) => {
      const selected = rows.filter((row) => row.currency === currency);
      const revenue = money(selected.filter((row) => row.accountType === 'revenue').reduce((sum, row) => sum + row.amount, 0));
      const expenses = money(selected.filter((row) => row.accountType === 'expense').reduce((sum, row) => sum + row.amount, 0));
      return { currency, revenue, expenses, netProfit: money(revenue - expenses) };
    }),
  };
}

export function buildBalanceSheet(accounts = [], entries = [], asOf = '', currencyFilter = '') {
  const lines = flattenPostedEntries(entries);
  const currencies = [...new Set(accounts.map((account) => account.currency).filter((currency) => !currencyFilter || currency === currencyFilter))].sort();
  const rows = [];
  const totals = [];
  for (const currency of currencies) {
    const currencyAccounts = accounts.filter((account) => account.currency === currency);
    const accountRows = currencyAccounts
      .filter((account) => ['asset', 'liability', 'equity'].includes(account.account_type))
      .map((account) => ({
        accountId: account.id,
        accountCode: account.account_code,
        accountName: account.account_name,
        accountType: account.account_type,
        currency,
        amount: accountBalance(lines, account, currency, asOf),
      }))
      .filter((row) => Math.abs(row.amount) >= 0.005);
    const income = buildIncomeStatement(accounts, entries, '', asOf, currency).totals[0] || { netProfit: 0 };
    const assets = money(accountRows.filter((row) => row.accountType === 'asset').reduce((sum, row) => sum + row.amount, 0));
    const liabilities = money(accountRows.filter((row) => row.accountType === 'liability').reduce((sum, row) => sum + row.amount, 0));
    const equity = money(accountRows.filter((row) => row.accountType === 'equity').reduce((sum, row) => sum + row.amount, 0));
    const retainedEarnings = money(income.netProfit);
    const totalEquityAndLiabilities = money(liabilities + equity + retainedEarnings);
    rows.push(...accountRows, ...(Math.abs(retainedEarnings) >= 0.005 ? [{ accountId: null, accountCode: 'RETAINED', accountName: 'نتيجة النشاط المتراكمة', accountType: 'retained_earnings', currency, amount: retainedEarnings }] : []));
    totals.push({ currency, assets, liabilities, equity, retainedEarnings, totalEquityAndLiabilities, difference: money(assets - totalEquityAndLiabilities) });
  }
  return { rows, totals };
}

export function buildGeneralLedger(accounts = [], entries = [], accountId = '', from = '', to = '') {
  const account = accounts.find((item) => item.id === accountId || item.account_code === accountId);
  if (!account) return { account: null, openingBalance: 0, rows: [], closingBalance: 0 };
  const lines = flattenPostedEntries(entries).filter((line) => line.account_id === account.id
    && line.currency === account.currency && (!to || line.entryDate <= to));
  const side = normalSide(account.account_type);
  const signed = (line) => side === 'debit'
    ? Number(line.debit || 0) - Number(line.credit || 0)
    : Number(line.credit || 0) - Number(line.debit || 0);
  const openingBalance = money(lines.filter((line) => from && line.entryDate < from).reduce((sum, line) => sum + signed(line), 0));
  let runningBalance = openingBalance;
  const rows = lines.filter((line) => inRange(line.entryDate, from, to)).map((line) => {
    runningBalance = money(runningBalance + signed(line));
    return {
      date: line.entryDate,
      entryNumber: line.entryNumber,
      description: line.description || line.entryDescription || '',
      debit: money(line.debit),
      credit: money(line.credit),
      balance: runningBalance,
      entryKind: line.entryKind,
      entryStatus: line.entryStatus,
    };
  });
  return { account, openingBalance, rows, closingBalance: runningBalance };
}

export const reportInternals = { flattenPostedEntries, normalSide };
