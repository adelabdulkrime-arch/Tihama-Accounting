const clean = (value) => String(value ?? '').trim();

export function validateVoucher(input) {
  const errors = [];
  if (!['RV', 'PV', 'TR', 'JV', 'ST'].includes(input.type)) errors.push('نوع السند غير صحيح.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date) || Number.isNaN(Date.parse(input.date))) errors.push('أدخل تاريخاً صحيحاً.');
  if (!(Number(input.amount) > 0) || !Number.isFinite(Number(input.amount))) errors.push('يجب أن يكون المبلغ أكبر من صفر.');
  if (!['YER', 'SAR', 'USD'].includes(input.currency)) errors.push('اختر عملة صحيحة.');
  if (!(Number(input.exchangeRate) > 0) || !Number.isFinite(Number(input.exchangeRate))) errors.push('سعر الصرف يجب أن يكون أكبر من صفر.');
  if (input.type === 'TR') {
    if (!clean(input.fromAccount) || !clean(input.toAccount)) errors.push('حدد حساب التحويل وحساب الاستلام.');
    if (clean(input.fromAccount) === clean(input.toAccount)) errors.push('يجب أن يكون حسابا التحويل والاستلام مختلفين.');
  } else if (input.type === 'JV') {
    const lines = Array.isArray(input.lines) ? input.lines : [];
    if (lines.length < 2) errors.push('القيد اليومي يحتاج إلى سطرين على الأقل.');
    let debit = 0; let credit = 0;
    for (const [index, line] of lines.entries()) {
      const dr = Number(line.debit || 0); const cr = Number(line.credit || 0);
      if (!clean(line.account)) errors.push(`حدد الحساب في السطر ${index + 1}.`);
      if (!Number.isFinite(dr) || !Number.isFinite(cr) || dr < 0 || cr < 0 || (dr > 0 && cr > 0) || (dr === 0 && cr === 0)) errors.push(`مبالغ السطر ${index + 1} غير صحيحة.`);
      debit += dr; credit += cr;
    }
    if (Math.abs(debit - credit) > 0.01) errors.push('القيد اليومي غير متوازن؛ يجب أن يتساوى إجمالي المدين والدائن.');
    if (Math.abs(debit - Number(input.amount)) > 0.01) errors.push('مبلغ القيد يجب أن يساوي إجمالي المدين.');
  } else {
    if (!clean(input.party)) errors.push('أدخل اسم الطرف أو المستفيد.');
    if (!clean(input.account)) errors.push('أدخل الحساب المالي.');
    if (['RV', 'PV'].includes(input.type) && !clean(input.category)) errors.push('اختر بند الإيراد أو المصروف.');
  }
  if (!clean(input.description)) errors.push('أدخل بيان السند.');
  return errors;
}
