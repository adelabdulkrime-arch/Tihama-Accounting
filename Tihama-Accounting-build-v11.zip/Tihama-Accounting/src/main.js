import './style.css';
import { supabase } from './lib/supabase.js';
import { VOUCHER_TYPES, getVouchers, saveDraft, watchVouchers, renderVoucherRows, escapeHtml } from './data/vouchers.js';
import { getLedgerAccounts, createLedgerAccount, setOpeningBalances, postVoucher, reverseVoucher, getLedgerSnapshot, getAccountingPeriods, closeAccountingPeriod, reopenAccountingPeriod, getAuditEvents } from './data/ledger.js';
import { buildBalanceSheet, buildGeneralLedger, buildIncomeStatement, buildTrialBalance } from './data/financial-reports.js';

const root = document.querySelector('#app');
const esc = (value = '') => String(value).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let member = null;
let busy = false;
let vouchers = [];
let ledgerAccounts = [];
let ledgerSnapshot = { entries: [], lines: [] };
let stopVoucherWatch = null;

function shell(content) {
  root.innerHTML = `<div class="app-shell"><header class="topbar"><div class="brand-mark">T</div><div><strong>رؤية تهامة</strong><small>النظام المحاسبي والإداري</small></div><span class="top-spacer"></span><span class="secure-label">اتصال آمن</span></header>${content}<footer>نظام مستقل · إدارة الصلاحيات عبر قاعدة البيانات</footer></div>`;
}
function message(text, type='error') {
  const el = document.querySelector('#notice');
  if (el) { el.textContent = text; el.className = `notice ${type}`; el.hidden = false; }
}
function setBusy(value) {
  busy = value;
  document.querySelectorAll('button').forEach((b) => b.disabled = value);
}
function loginView() {
  shell(`<main class="auth-card"><div class="eyebrow">بوابة الدخول</div><h1>مرحباً بعودتك</h1><p class="muted">سجّل الدخول للوصول إلى مساحة العمل المحاسبية.</p><form id="login-form"><label for="email">البريد الإلكتروني</label><input id="email" name="email" type="email" autocomplete="username" required placeholder="name@example.com" dir="ltr"><label for="password">كلمة المرور</label><input id="password" name="password" type="password" autocomplete="current-password" required placeholder="أدخل كلمة المرور" dir="ltr"><div id="notice" class="notice" hidden></div><button class="primary" type="submit">تسجيل الدخول</button></form><p class="hint">حالياً الدخول بالبريد الإلكتروني. دعم اسم المستخدم سيضاف عبر مسار خادمي آمن، دون كشف بريد الحساب أو تخزين كلمات المرور في قاعدة بيانات التطبيق.</p></main>`);
  document.querySelector('#login-form').addEventListener('submit', async (event) => {
    event.preventDefault(); if (busy) return;
    const fd = new FormData(event.currentTarget);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: String(fd.get('email')).trim(), password: String(fd.get('password')) });
    setBusy(false);
    if (error) { message('تعذر تسجيل الدخول. تحقق من بيانات الدخول وحالة الحساب.'); return; }
    await loadSession();
  });
}
function passwordView() {
  shell(`<main class="auth-card"><div class="eyebrow">إجراء أمني إلزامي</div><h1>تحديث كلمة المرور</h1><p class="muted">هذه أول مرة تدخل فيها إلى النظام. يجب تعيين كلمة مرور جديدة قبل المتابعة.</p><form id="password-form"><label for="new-password">كلمة المرور الجديدة</label><input id="new-password" type="password" autocomplete="new-password" minlength="10" required dir="ltr" placeholder="10 أحرف على الأقل"><label for="confirm-password">تأكيد كلمة المرور</label><input id="confirm-password" type="password" autocomplete="new-password" minlength="10" required dir="ltr" placeholder="أعد إدخال كلمة المرور"><div id="notice" class="notice" hidden></div><button class="primary" type="submit">حفظ ومتابعة</button><button class="secondary" id="cancel-login" type="button">تسجيل الخروج</button></form><p class="hint">استخدم كلمة مرور فريدة لا تستخدمها في خدمات أخرى.</p></main>`);
  document.querySelector('#cancel-login').addEventListener('click', () => supabase.auth.signOut().then(loginView));
  document.querySelector('#password-form').addEventListener('submit', async (event) => {
    event.preventDefault(); if (busy) return;
    const password = document.querySelector('#new-password').value;
    const confirm = document.querySelector('#confirm-password').value;
    if (password.length < 10) return message('يجب ألا تقل كلمة المرور عن 10 أحرف.');
    if (password !== confirm) return message('كلمتا المرور غير متطابقتين.');
    setBusy(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    if (updateError) { setBusy(false); return message('تعذر تحديث كلمة المرور. حاول مجدداً.'); }
    const { error: setupError } = await supabase.rpc('complete_own_password_setup');
    setBusy(false);
    if (setupError) return message('تم تحديث كلمة المرور، لكن تعذر إكمال تهيئة الحساب. لا تسجل الخروج؛ أعد المحاولة أو تواصل مع مدير النظام.');
    await loadSession();
  });
}
function accountOptions(filter = {}) {
  const rows = ledgerAccounts.filter((a) => a.is_active && (!filter.cash || a.is_cash) && (!filter.type || a.account_type === filter.type) && (!filter.currency || a.currency === filter.currency));
  return `<option value="">— اختر الحساب من دليل الحسابات —</option>${rows.map((a) => `<option value="${esc(a.account_code)}">${esc(a.account_code)} · ${esc(a.account_name)}${a.external_account_number ? ` · ${esc(a.external_account_number)}` : ''} (${esc(a.currency)})</option>`).join('')}`;
}
function accountPanel() {
  const typeNames = { asset: 'أصول', liability: 'التزامات', equity: 'حقوق ملكية', revenue: 'إيرادات', expense: 'مصروفات' };
  const balances = new Map();
  for (const line of ledgerSnapshot.lines || []) { const key = line.account_id; balances.set(key, (balances.get(key) || 0) + Number(line.debit || 0) - Number(line.credit || 0)); }
  const fmt = (n) => Number(n).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
  const rows = ledgerAccounts.map((a) => { const balance = Number(a.opening_balance || 0) + (balances.get(a.id) || 0); return `<tr><td>${esc(a.account_code)}</td><td>${esc(a.account_name)}</td><td>${esc(a.institution_name || '—')}</td><td dir="ltr">${esc(a.external_account_number || '—')}</td><td dir="ltr">${esc(a.alternate_reference || '—')}</td><td>${esc(typeNames[a.account_type] || a.account_type)}</td><td>${esc(a.currency)}</td><td>${fmt(balance)} ${esc(a.currency)}</td><td>${a.is_cash ? 'نقدي' : '—'}</td><td>${esc(a.category_key || '—')}</td><td>${a.is_active ? 'نشط' : 'موقوف'}</td></tr>`; }).join('');
  const openingCodes = new Set((ledgerSnapshot.entries || []).filter((e) => e.source_collection === 'opening_balances' && e.status === 'posted').map((e) => e.source_record_id));
  const cashWithPriorActivity = ledgerAccounts.filter((a) => a.is_active && a.is_cash && a.account_type === 'asset' && !openingCodes.has(a.account_code) && (Number(a.opening_balance || 0) !== 0 || (ledgerSnapshot.lines || []).some((line) => line.account_id === a.id)));
  const pendingCash = ledgerAccounts.filter((a) => a.is_active && a.is_cash && a.account_type === 'asset' && !openingCodes.has(a.account_code) && Number(a.opening_balance || 0) === 0 && !(ledgerSnapshot.lines || []).some((line) => line.account_id === a.id));
  const openingForm = member?.role === 'admin' ? `<form id="opening-balance-form" class="voucher-form"><h3 class="subheading">إثبات الأرصدة الافتتاحية</h3><p class="hint">أدخل الرصيد الفعلي كما يظهر في كشف البنك أو المحفظة بتاريخ بداية العمل. يرحّل النظام كل حساب بقيد مستقل متوازن، ولا يسمح بالتكرار.</p>${cashWithPriorActivity.length ? `<p class="notice warning">هناك ${cashWithPriorActivity.length} حساب/حسابات عليها حركات سابقة أو رصيد افتتاحي سابق؛ استُبعدت من هذه الشاشة منعاً لتكرار الرصيد أو مضاعفته.</p>` : ''}<div class="form-grid"><label>تاريخ الرصيد<input name="entryDate" type="date" required value="${new Date().toISOString().slice(0,10)}"></label><label class="wide">بيان القيد<input name="description" maxlength="180" required value="الأرصدة الافتتاحية حسب كشوف الحسابات"></label></div><div class="table-wrap"><table class="data-table"><thead><tr><th>الحساب</th><th>الجهة</th><th>رقم الحساب</th><th>العملة</th><th>الرصيد الافتتاحي</th></tr></thead><tbody>${pendingCash.map((a) => `<tr><td>${esc(a.account_name)}<small class="hint" dir="ltr">${esc(a.account_code)}</small></td><td>${esc(a.institution_name || '—')}</td><td dir="ltr">${esc(a.external_account_number || '—')}</td><td>${esc(a.currency)}</td><td><input class="opening-amount" data-account-code="${esc(a.account_code)}" type="number" min="0.01" step="0.01" placeholder="أدخل الرصيد" inputmode="decimal"></td></tr>`).join('') || '<tr><td colspan="5" class="empty">تم تسجيل الأرصدة الافتتاحية لجميع الحسابات النقدية.</td></tr>'}</tbody></table></div>${pendingCash.length ? '<div class="form-actions"><button class="primary" type="submit">ترحيل الأرصدة الافتتاحية</button></div>' : ''}</form>` : '';
  return `<div class="table-wrap"><table class="data-table"><thead><tr><th>الرمز الداخلي</th><th>اسم الحساب</th><th>البنك / المحفظة</th><th>رقم الحساب</th><th>الرقم البديل</th><th>التصنيف</th><th>العملة</th><th>الرصيد الدفتري</th><th>الصفة</th><th>ربط البند</th><th>الحالة</th></tr></thead><tbody>${rows || '<tr><td colspan="11" class="empty">لم يُنشأ دليل حسابات بعد.</td></tr>'}</tbody></table></div>${openingForm}${member?.role === 'admin' ? `<form id="account-form" class="voucher-form"><h3 class="subheading">إضافة حساب جديد</h3><div class="form-grid"><label>رمز الحساب<input name="accountCode" required maxlength="30" placeholder="مثال: 1110" dir="ltr"></label><label>اسم الحساب<input name="accountName" required maxlength="160"></label><label>نوع الحساب<select name="accountType"><option value="asset">أصول</option><option value="liability">التزامات</option><option value="equity">حقوق ملكية</option><option value="revenue">إيرادات</option><option value="expense">مصروفات</option></select></label><label>العملة<select name="currency"><option>YER</option><option>SAR</option><option>USD</option></select></label><label>ربط بند الإيراد / المصروف (عند الحاجة)<input name="categoryKey" maxlength="120" placeholder="يجب أن يطابق بند السند"></label><label class="check-label"><input type="checkbox" name="isCash"> حساب نقدي (صندوق / بنك / محفظة)</label></div><div class="form-actions"><button class="primary" type="submit">إضافة إلى دليل الحسابات</button><span class="hint">لا يمكن حذف الحساب بعد استخدامه في قيد.</span></div></form>` : ''}`;
}
function renderJournalPreview(snapshot) {
  const lines = snapshot.lines || [];
  if (!lines.length) return '<p class="empty">لا توجد قيود مرحلة بعد. يلزم إنشاء دليل الحسابات وربط بنود الإيرادات والمصروفات قبل اعتماد السندات.</p>';
  const totals = new Map();
  const trial = new Map();
  for (const line of lines) {
    const currency = line.currency;
    const t = totals.get(currency) || { currency, debit: 0, credit: 0 };
    t.debit += Number(line.debit || 0); t.credit += Number(line.credit || 0); totals.set(currency, t);
    const name = line.account?.account_name || 'حساب غير معروف';
    const key = `${line.account_id}|${currency}`;
    const row = trial.get(key) || { account: name, code: line.account?.account_code || '', currency, debit: 0, credit: 0 };
    row.debit += Number(line.debit || 0); row.credit += Number(line.credit || 0); trial.set(key, row);
  }
  const fmt = (n) => Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const totalRows = [...totals.values()].map((x) => `<tr><td>${esc(x.currency)}</td><td>${fmt(x.debit)}</td><td>${fmt(x.credit)}</td><td><span class="status ${Math.abs(x.debit-x.credit)<=0.01?'status-approved':'status-warning'}">${Math.abs(x.debit-x.credit)<=0.01?'متوازن':'غير متوازن'}</span></td></tr>`).join('');
  const trialRows = [...trial.values()].sort((a,b)=>a.code.localeCompare(b.code)).map((x) => `<tr><td>${esc(x.code)}</td><td>${esc(x.account)}</td><td>${esc(x.currency)}</td><td>${fmt(Math.max(x.debit-x.credit,0))}</td><td>${fmt(Math.max(x.credit-x.debit,0))}</td></tr>`).join('');
  const entryRows = (snapshot.entries || []).slice(0,30).map((e) => `<tr><td>${e.entry_number}</td><td>${esc(e.entry_date)}</td><td>${esc(e.description)}</td><td>${esc(e.currency)}</td><td>${e.entry_kind === 'reversal' ? 'قيد عكسي' : e.entry_kind === 'opening' ? 'قيد افتتاحي' : 'قيد سند'}</td><td>${e.status === 'reversed' ? 'عُكس' : 'مرحّل'}</td></tr>`).join('');
  return `<h3 class="subheading">إجماليات دفتر اليومية</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>العملة</th><th>إجمالي المدين</th><th>إجمالي الدائن</th><th>التوازن</th></tr></thead><tbody>${totalRows}</tbody></table></div><h3 class="subheading">ميزان المراجعة</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>الرمز</th><th>الحساب</th><th>العملة</th><th>رصيد مدين</th><th>رصيد دائن</th></tr></thead><tbody>${trialRows}</tbody></table></div><h3 class="subheading">آخر القيود المرحلة</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>رقم القيد</th><th>التاريخ</th><th>البيان</th><th>العملة</th><th>النوع</th><th>الحالة</th></tr></thead><tbody>${entryRows}</tbody></table></div><p class="hint">فروق العملة، إقفال الفترات، وربط الرواتب والأصول لم تُفعّل بعد؛ لذلك لا يُعد هذا الميزان شاملاً لكل وحدات النظام.</p>`;
}

function reportMoney(value) { return Number(value || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function financialReportsPanel() {
  const today = new Date().toISOString().slice(0, 10);
  const yearStart = `${today.slice(0, 4)}-01-01`;
  return `<section class="module-panel"><div class="panel-head"><div><h2>القوائم المالية ودفتر الأستاذ</h2><p class="muted">تقارير مستخرجة حصراً من قيود دفتر الأستاذ المرحلة، مع فصل مستقل لكل عملة.</p></div><span class="tag">تقارير مالية</span></div>
    <form id="financial-report-form" class="voucher-form"><div class="form-grid">
      <label>نوع التقرير<select name="reportType"><option value="trial">ميزان المراجعة</option><option value="income">قائمة الدخل</option><option value="balance">الميزانية العمومية</option><option value="ledger">دفتر الأستاذ التفصيلي</option></select></label>
      <label>من تاريخ<input name="from" type="date" value="${yearStart}"></label><label>إلى تاريخ / كما في<input name="to" type="date" value="${today}" required></label>
      <label>العملة<select name="currency"><option value="">جميع العملات (كل عملة منفصلة)</option>${[...new Set(ledgerAccounts.map((a) => a.currency))].sort().map((c) => `<option>${esc(c)}</option>`).join('')}</select></label>
      <label class="wide">الحساب (للدفتر التفصيلي فقط)<select name="accountId"><option value="">— اختر الحساب —</option>${ledgerAccounts.map((a) => `<option value="${esc(a.id)}">${esc(a.account_code)} · ${esc(a.account_name)} (${esc(a.currency)})</option>`).join('')}</select></label>
    </div><div class="form-actions"><button class="primary" type="submit">إنشاء التقرير</button><button class="secondary" type="button" id="print-financial-report">طباعة التقرير</button></div></form><div id="financial-report-output"><p class="empty">اختر نوع التقرير والفترة ثم اضغط إنشاء التقرير.</p></div></section>`;
}
function renderFinancialReport({ reportType, from, to, currency, accountId }) {
  const fmt = reportMoney;
  if (from && to && from > to) return '<p class="notice warning">تاريخ البداية يجب ألا يتجاوز تاريخ النهاية.</p>';
  if (reportType === 'trial') {
    const report = buildTrialBalance(ledgerAccounts, ledgerSnapshot.entries, to);
    const groups = [...new Set(report.rows.filter((r) => !currency || r.currency === currency).map((r) => r.currency))];
    if (!groups.length) return '<p class="empty">لا توجد أرصدة مرحلة حتى التاريخ المحدد.</p>';
    return `<h3 class="subheading">ميزان المراجعة كما في ${esc(to)}</h3>${groups.map((cur) => { const rows = report.rows.filter((r) => r.currency === cur); const total = report.totals.find((r) => r.currency === cur) || { debit: 0, credit: 0 }; return `<h4>${esc(cur)}</h4><div class="table-wrap"><table class="data-table"><thead><tr><th>رمز الحساب</th><th>الحساب</th><th>مدين</th><th>دائن</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(r.accountCode)}</td><td>${esc(r.accountName)}</td><td>${fmt(r.debit)}</td><td>${fmt(r.credit)}</td></tr>`).join('')}<tr><th colspan="2">الإجمالي</th><th>${fmt(total.debit)}</th><th>${fmt(total.credit)}</th></tr></tbody></table></div><p class="hint">${Math.abs(total.debit-total.credit) <= 0.01 ? 'الميزان متوازن' : `فرق الميزان: ${fmt(total.debit-total.credit)} ${esc(cur)}`}</p>`; }).join('')}`;
  }
  if (reportType === 'income') {
    const report = buildIncomeStatement(ledgerAccounts, ledgerSnapshot.entries, from, to, currency);
    if (!report.totals.length) return '<p class="empty">لا توجد حركات إيرادات أو مصروفات مرحلة في الفترة المحددة.</p>';
    return `<h3 class="subheading">قائمة الدخل من ${esc(from || 'بداية السجلات')} إلى ${esc(to)}</h3>${report.totals.map((total) => { const rows = report.rows.filter((r) => r.currency === total.currency); return `<h4>${esc(total.currency)}</h4><div class="table-wrap"><table class="data-table"><thead><tr><th>رمز الحساب</th><th>البيان</th><th>التصنيف</th><th>المبلغ</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(r.accountCode)}</td><td>${esc(r.accountName)}</td><td>${r.accountType === 'revenue' ? 'إيراد' : 'مصروف'}</td><td>${fmt(r.amount)}</td></tr>`).join('')}<tr><th colspan="3">إجمالي الإيرادات</th><th>${fmt(total.revenue)}</th></tr><tr><th colspan="3">إجمالي المصروفات</th><th>${fmt(total.expenses)}</th></tr><tr><th colspan="3">صافي الربح / (الخسارة)</th><th>${fmt(total.netProfit)} ${esc(total.currency)}</th></tr></tbody></table></div>`; }).join('')}`;
  }
  if (reportType === 'balance') {
    const report = buildBalanceSheet(ledgerAccounts, ledgerSnapshot.entries, to, currency);
    if (!report.totals.length) return '<p class="empty">لا توجد حسابات أو أرصدة للعملة المحددة.</p>';
    return `<h3 class="subheading">الميزانية العمومية كما في ${esc(to)}</h3>${report.totals.map((total) => { const rows = report.rows.filter((r) => r.currency === total.currency); const section = (type) => rows.filter((r) => r.accountType === type).map((r) => `<tr><td>${esc(r.accountCode)}</td><td>${esc(r.accountName)}</td><td>${fmt(r.amount)}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">لا توجد أرصدة</td></tr>'; return `<h4>${esc(total.currency)}</h4><div class="table-wrap"><table class="data-table"><thead><tr><th>الرمز</th><th>الحساب</th><th>الرصيد</th></tr></thead><tbody><tr><th colspan="3">الأصول</th></tr>${section('asset')}<tr><th colspan="2">إجمالي الأصول</th><th>${fmt(total.assets)}</th></tr><tr><th colspan="3">الالتزامات</th></tr>${section('liability')}<tr><th colspan="2">إجمالي الالتزامات</th><th>${fmt(total.liabilities)}</th></tr><tr><th colspan="3">حقوق الملكية</th></tr>${section('equity')}<tr><td>—</td><td>نتيجة النشاط المتراكمة</td><td>${fmt(total.retainedEarnings)}</td></tr><tr><th colspan="2">إجمالي الالتزامات وحقوق الملكية</th><th>${fmt(total.totalEquityAndLiabilities)}</th></tr></tbody></table></div><p class="hint">${Math.abs(total.difference) <= 0.01 ? 'الميزانية متوازنة' : `تنبيه: فرق الميزانية ${fmt(total.difference)} ${esc(total.currency)}؛ يلزم مراجعة القيود.`}</p>`; }).join('')}`;
  }
  if (reportType === 'ledger') {
    if (!accountId) return '<p class="notice warning">اختر حساباً لعرض دفتر الأستاذ التفصيلي.</p>';
    const report = buildGeneralLedger(ledgerAccounts, ledgerSnapshot.entries, accountId, from, to);
    if (!report.account) return '<p class="notice warning">الحساب المحدد غير موجود.</p>';
    return `<h3 class="subheading">دفتر الأستاذ: ${esc(report.account.account_code)} · ${esc(report.account.account_name)} (${esc(report.account.currency)})</h3><p class="hint">الفترة: ${esc(from || 'بداية السجلات')} إلى ${esc(to)} · الرصيد الافتتاحي: ${fmt(report.openingBalance)} ${esc(report.account.currency)}</p><div class="table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>رقم القيد</th><th>البيان</th><th>مدين</th><th>دائن</th><th>الرصيد الجاري</th></tr></thead><tbody>${report.rows.map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.entryNumber)}</td><td>${esc(r.description)}</td><td>${fmt(r.debit)}</td><td>${fmt(r.credit)}</td><td>${fmt(r.balance)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا توجد حركات في الفترة.</td></tr>'}<tr><th colspan="5">الرصيد الختامي</th><th>${fmt(report.closingBalance)} ${esc(report.account.currency)}</th></tr></tbody></table></div>`;
  }
  return '<p class="notice warning">نوع التقرير غير معروف.</p>';
}

function renderAuditEvents(events) {
  if (!events.length) return '<p class="empty">لا توجد أحداث مسجلة حتى الآن.</p>';
  const labels = { voucher_posted: 'ترحيل سند', voucher_reversed: 'عكس / إلغاء سند', opening_balance_posted: 'ترحيل رصيد افتتاحي', accounting_period_closed: 'إقفال فترة', accounting_period_reopened: 'إعادة فتح فترة', create: 'إنشاء سجل', update: 'تحديث سجل', delete: 'حذف سجل' };
  return `<div class="table-wrap"><table class="data-table"><thead><tr><th>التاريخ والوقت</th><th>المنفذ</th><th>الإجراء</th><th>نوع السجل</th><th>المعرف</th><th>التفاصيل</th></tr></thead><tbody>${events.map(e => `<tr><td dir="ltr">${esc(new Date(e.created_at).toLocaleString('en-GB'))}</td><td>${esc(e.actor_name || 'مستخدم النظام')}</td><td>${esc(labels[e.action] || e.action)}</td><td>${esc(e.entity_type || '—')}</td><td dir="ltr">${esc(e.entity_id || '—')}</td><td><code>${esc(JSON.stringify(e.details || {}))}</code></td></tr>`).join('')}</tbody></table></div>`;
}

function renderAccountingPeriods(periods) {
  if (!periods.length) return '<p class="empty">لا توجد فترات محاسبية مغلقة حتى الآن.</p>';
  return `<div class="table-wrap"><table class="data-table"><thead><tr><th>من تاريخ</th><th>إلى تاريخ</th><th>الحالة</th><th>سبب الإقفال</th><th>تاريخ الإجراء</th><th>الإجراء</th></tr></thead><tbody>${periods.map((p) => `<tr><td dir="ltr">${esc(p.period_start)}</td><td dir="ltr">${esc(p.period_end)}</td><td><span class="status ${p.status === 'closed' ? 'status-warning' : 'status-approved'}">${p.status === 'closed' ? 'مغلقة' : 'أعيد فتحها'}</span></td><td>${esc(p.status === 'closed' ? p.close_reason : (p.reopen_reason || p.close_reason))}</td><td dir="ltr">${esc(p.status === 'closed' ? p.closed_at : p.reopened_at)}</td><td>${p.status === 'closed' && member?.role === 'admin' ? `<button class="small-action reverse-action" data-period-action="reopen" data-start="${esc(p.period_start)}" data-end="${esc(p.period_end)}">إعادة فتح</button>` : '—'}</td></tr>`).join('')}</tbody></table></div>`;
}

function dashboardView() {
  const roleNames = { admin: 'مدير النظام', editor: 'محرر', viewer: 'مستخدم للقراءة' };
  const canEdit = ['admin', 'editor'].includes(member.role);
  shell(`<main class="workspace"><section class="welcome"><div><div class="eyebrow">مساحة العمل</div><h1>مرحباً، ${esc(member.display_name || 'مستخدم النظام')}</h1><p class="muted">تم التحقق من هويتك وصلاحياتك من قاعدة البيانات.</p></div><button id="logout" class="secondary">تسجيل الخروج</button></section>
  <section class="status-grid"><article class="status-card"><span>حالة الحساب</span><strong class="good">نشط</strong></article><article class="status-card"><span>مستوى الصلاحية</span><strong>${esc(roleNames[member.role] || member.role)}</strong></article><article class="status-card"><span>مصدر الصلاحيات</span><strong>Supabase RLS</strong></article></section>
  <section class="module-panel"><div class="panel-head"><div><h2>دليل الحسابات</h2><p class="muted">إعداد الحسابات وربط بنود الإيرادات والمصروفات قبل الترحيل.</p></div><span class="tag">إعداد أساسي</span></div><div id="accounts-panel">${accountPanel()}</div></section>
  <section class="module-panel"><div class="panel-head"><div><h2>السندات المالية</h2><p class="muted">تسجيل مسودات سندات القبض والصرف والتحويل الداخلي ومتابعة حالتها.</p></div><span class="tag">المرحلة الأولى</span></div>
  ${canEdit ? `<form id="voucher-form" class="voucher-form"><div class="form-grid">
    <label>نوع السند<select name="type" required><option value="RV">سند قبض</option><option value="PV">سند صرف</option><option value="TR">تحويل داخلي</option></select></label>
    <label>التاريخ<input name="date" type="date" required value="${new Date().toISOString().slice(0,10)}"></label>
    <label>الطرف / المستفيد<input name="party" maxlength="180" placeholder="اسم الطرف"></label>
    <label>بند الإيراد / المصروف<select name="category"><option value="">— اختر البند —</option>${[...new Set(ledgerAccounts.filter(a => a.category_key && a.is_active).map(a => a.category_key))].map(x => `<option>${esc(x)}</option>`).join('')}</select></label>
    <label>العملة<select name="currency"><option>YER</option><option>SAR</option><option>USD</option></select></label>
    <label>المبلغ<input name="amount" type="number" min="0.01" step="0.01" required></label>
    <label>الحساب المالي<select name="account">${accountOptions({cash:true})}</select></label>
    <label>حساب التحويل منه<select name="fromAccount">${accountOptions({cash:true})}</select></label>
    <label>حساب الاستلام إليه<select name="toAccount">${accountOptions({cash:true})}</select></label>
    <label>سعر الصرف<input name="exchangeRate" type="number" min="0.000001" step="any" value="1"></label>
    <label>طريقة الدفع<select name="paymentMethod"><option>نقداً</option><option>حوالة بنكية</option><option>تحويل بنكي</option><option>محفظة إلكترونية</option></select></label>
    <label>رقم المرجع<input name="reference" maxlength="120"></label>
    <label class="wide">البيان<textarea name="description" maxlength="1000" required></textarea></label>
    <label class="wide">ملاحظات<textarea name="notes" maxlength="1000"></textarea></label>
  </div><div class="form-actions"><button class="primary" type="submit">حفظ كمسودة</button><span class="hint">يُحفظ السند كمسودة؛ ويعتمده مدير النظام بعد استكمال ربط الحسابات.</span></div></form>` : `<p class="hint">صلاحيتك للقراءة فقط. يمكنك استعراض السندات دون إنشاء أو تعديل.</p>`}
  <div class="table-wrap"><table class="data-table"><thead><tr><th>رقم السند</th><th>التاريخ</th><th>النوع</th><th>الطرف</th><th>المبلغ</th><th>الحالة</th><th>البيان</th><th>الإجراء</th></tr></thead><tbody id="voucher-rows"><tr><td colspan="8">جارٍ تحميل السندات…</td></tr></tbody></table></div></section>
  <section class="module-panel"><div class="panel-head"><div><h2>قيد يومية عام</h2><p class="muted">إنشاء قيد متوازن من حسابات دليل الحسابات وبالعملة نفسها.</p></div><span class="tag">JV</span></div>
  ${canEdit ? `<form id="journal-voucher-form" class="voucher-form"><div class="form-grid"><label>التاريخ<input name="date" type="date" required value="${new Date().toISOString().slice(0,10)}"></label><label>العملة<select name="currency"><option>YER</option><option>SAR</option><option>USD</option></select></label><label class="wide">البيان<textarea name="description" maxlength="1000" required></textarea></label></div>
  <div class="table-wrap"><table class="data-table"><thead><tr><th>الحساب</th><th>البيان التفصيلي</th><th>مدين</th><th>دائن</th></tr></thead><tbody>${[0,1,2,3].map((i) => `<tr><td><select class="jv-account" required>${accountOptions({currency:'YER'})}</select></td><td><input class="jv-description" maxlength="180" placeholder="اختياري"></td><td><input class="jv-debit" type="number" min="0" step="0.01" value="0"></td><td><input class="jv-credit" type="number" min="0" step="0.01" value="0"></td></tr>`).join('')}</tbody></table></div>
  <div class="form-actions"><strong id="jv-totals" class="hint">إجمالي المدين: 0.00 | إجمالي الدائن: 0.00</strong><button class="primary" type="submit">حفظ القيد كمسودة</button></div></form>` : `<p class="hint">صلاحيتك للقراءة فقط.</p>`}</section>
  <section class="module-panel"><div class="panel-head"><div><h2>دفتر اليومية وميزان المراجعة</h2><p class="muted">دفتر اليومية وميزان المراجعة المستخرجان من قيود قاعدة البيانات المرحلة فعلياً.</p></div><span class="tag">قراءة فقط</span></div><div id="journal-preview">${renderJournalPreview(ledgerSnapshot)}</div></section>
  ${financialReportsPanel()}
  <section class="module-panel"><div class="panel-head"><div><h2>إقفال الفترات المحاسبية</h2><p class="muted">قفل الترحيل والإلغاء داخل الفترة بعد التحقق من اكتمال القيود وعدم وجود سندات معلقة.</p></div><span class="tag">ضبط محاسبي</span></div>${member.role === 'admin' ? `<form id="accounting-period-form" class="voucher-form"><div class="form-grid"><label>من تاريخ<input name="start" type="date" required></label><label>إلى تاريخ<input name="end" type="date" required></label><label class="wide">سبب الإقفال<input name="reason" minlength="5" maxlength="300" required placeholder="مثال: إقفال شهر نوفمبر بعد المطابقة البنكية"></label></div><div class="form-actions"><button class="primary" type="submit">إقفال الفترة المحددة</button><span class="hint">لا يمكن الإقفال مع وجود سندات مسودة أو قيود غير متوازنة. إعادة الفتح تتطلب سبباً موثقاً.</span></div></form>` : `<p class="hint">عرض الفترات فقط؛ الإقفال وإعادة الفتح متاحان لمدير النظام.</p>`}<div id="accounting-periods-list"><p class="empty">جارٍ تحميل الفترات…</p></div></section>
  <section class="module-panel"><div class="panel-head"><div><h2>سجل المراجعة</h2><p class="muted">عرض سجل العمليات الحساسة المسجل من قاعدة البيانات؛ لا يعرض محتويات السندات أو البيانات السرية.</p></div><span class="tag">للمدير فقط</span></div>${member.role === 'admin' ? `<div class="form-actions"><button class="secondary" id="refresh-audit" type="button">تحديث السجل</button></div><div id="audit-events-list"><p class="empty">جارٍ تحميل سجل المراجعة…</p></div>` : `<p class="hint">سجل المراجعة محجوب عن هذا الدور.</p>`}</section>
  <section class="module-panel"><div class="panel-head"><div><h2>الوحدات التالية</h2><p class="muted">ستُفعّل بعد نقل منطقها واختبارها.</p></div></div><div class="module-grid"><div class="module"><b>القيود والتسويات</b><small>دفتر اليومية · الترحيل</small></div><div class="module"><b>الموظفون والرواتب</b><small>بيانات الموظفين · الرواتب · السلف</small></div><div class="module"><b>العهد والأصول</b><small>العهد المالية · الأصول الثابتة</small></div><div class="module"><b>التقارير المحاسبية</b><small>الأستاذ · ميزان المراجعة · الإقفال</small></div><div class="module"><b>العملاء والملفات</b><small>السجلات · المرفقات · الاستيراد</small></div><div class="module"><b>سجل المراجعة</b><small>سجل خادمي للعمليات الحساسة متاح لمدير النظام</small></div></div></section><div id="notice" class="notice" hidden></div></main>`);
  document.querySelector('#logout').addEventListener('click', async () => { setBusy(true); const { error } = await supabase.auth.signOut(); setBusy(false); if (error) message('تعذر تسجيل الخروج.'); else loginView(); });
  if (stopVoucherWatch) stopVoucherWatch();
  const refresh = (rows) => { vouchers = rows; const tbody = document.querySelector('#voucher-rows'); if (tbody) tbody.innerHTML = renderVoucherRows(rows, member.role === 'admin'); };
  const syncVoucherFields = () => { const form = document.querySelector('#voucher-form'); if (!form) return; const currency = form.elements.currency.value; const type = form.elements.type.value; const categoryType = type === 'RV' ? 'revenue' : 'expense'; for (const name of ['account','fromAccount','toAccount']) { const select = form.elements[name]; const previous = select.value; select.innerHTML = accountOptions({ cash: true, currency }); if ([...select.options].some(o => o.value === previous)) select.value = previous; } const category = form.elements.category; const previousCategory = category.value; const keys = [...new Set(ledgerAccounts.filter(a => a.is_active && a.account_type === categoryType && a.currency === currency && a.category_key).map(a => a.category_key))]; category.innerHTML = '<option value="">— اختر البند —</option>' + keys.map(k => `<option>${esc(k)}</option>`).join(''); if (keys.includes(previousCategory)) category.value = previousCategory; };
  const refreshLedger = async () => { try { const [accounts, snapshot] = await Promise.all([getLedgerAccounts(), getLedgerSnapshot()]); ledgerAccounts = accounts; ledgerSnapshot = snapshot; const panel = document.querySelector('#accounts-panel'); if (panel) panel.innerHTML = accountPanel(); syncVoucherFields(); syncJournalVoucherFields(); const preview = document.querySelector('#journal-preview'); if (preview) preview.innerHTML = renderJournalPreview(snapshot); syncFinancialReportFields(); } catch (error) { message('تعذر تحميل دليل الحسابات أو دفتر الأستاذ: ' + (error.message || 'تحقق من الصلاحيات.')); } };
  const refreshPeriods = async () => { try { const periods = await getAccountingPeriods(); const list = document.querySelector('#accounting-periods-list'); if (list) list.innerHTML = renderAccountingPeriods(periods); } catch (error) { const list = document.querySelector('#accounting-periods-list'); if (list) list.innerHTML = '<p class="notice warning">تعذر تحميل الفترات المحاسبية؛ تحقق من صلاحيات القراءة.</p>'; } };
  const refreshAudit = async () => { if (member.role !== 'admin') return; const list = document.querySelector('#audit-events-list'); if (!list) return; try { const events = await getAuditEvents(50, 0); list.innerHTML = renderAuditEvents(events); } catch (error) { list.innerHTML = '<p class="notice warning">تعذر تحميل سجل المراجعة. تحقق من صلاحيات المدير.</p>'; } };
  const reportForm = document.querySelector('#financial-report-form');
  if (reportForm) reportForm.addEventListener('submit', (event) => { event.preventDefault(); const values = Object.fromEntries(new FormData(reportForm).entries()); const output = document.querySelector('#financial-report-output'); if (output) output.innerHTML = renderFinancialReport(values); });
  document.querySelector('#print-financial-report')?.addEventListener('click', () => window.print());
  getVouchers().then(refresh).catch(() => message('تعذر تحميل السندات. تحقق من سياسات الوصول في قاعدة البيانات.'));
  refreshLedger();
  refreshPeriods();
  refreshAudit();
  stopVoucherWatch = watchVouchers(refresh, () => message('انقطع تحديث السندات المباشر؛ حدّث الصفحة لإعادة الاتصال.', 'warning'));
  const syncJournalVoucherFields = () => { const form = document.querySelector('#journal-voucher-form'); if (!form) return; const currency = form.elements.currency.value; form.querySelectorAll('.jv-account').forEach((select) => { const previous = select.value; select.innerHTML = accountOptions({currency}); if ([...select.options].some((o) => o.value === previous)) select.value = previous; }); };
  const syncFinancialReportFields = () => { const form = document.querySelector('#financial-report-form'); if (!form) return; const currency = form.elements.currency.value; const accountId = form.elements.accountId.value; form.elements.currency.innerHTML = '<option value="">جميع العملات (كل عملة منفصلة)</option>' + [...new Set(ledgerAccounts.map((a) => a.currency))].sort().map((c) => `<option>${esc(c)}</option>`).join(''); form.elements.currency.value = currency; form.elements.accountId.innerHTML = '<option value="">— اختر الحساب —</option>' + ledgerAccounts.map((a) => `<option value="${esc(a.id)}">${esc(a.account_code)} · ${esc(a.account_name)} (${esc(a.currency)})</option>`).join(''); form.elements.accountId.value = accountId; };
  const journalVoucherForm = document.querySelector('#journal-voucher-form');
  if (journalVoucherForm) {
    journalVoucherForm.elements.currency.addEventListener('change', syncJournalVoucherFields);
    const updateJvTotals = () => { const debit = [...journalVoucherForm.querySelectorAll('.jv-debit')].reduce((sum, el) => sum + Number(el.value || 0), 0); const credit = [...journalVoucherForm.querySelectorAll('.jv-credit')].reduce((sum, el) => sum + Number(el.value || 0), 0); const totals = document.querySelector('#jv-totals'); if (totals) totals.textContent = `إجمالي المدين: ${debit.toFixed(2)} | إجمالي الدائن: ${credit.toFixed(2)} | ${Math.abs(debit-credit) <= 0.01 ? 'متوازن' : 'غير متوازن'}`; };
    journalVoucherForm.addEventListener('input', updateJvTotals);
    syncJournalVoucherFields();
    journalVoucherForm.addEventListener('submit', async (event) => {
      event.preventDefault(); if (busy) return;
      const lines = [...journalVoucherForm.querySelectorAll('tbody tr')].map((tr) => ({ account: tr.querySelector('.jv-account').value, description: tr.querySelector('.jv-description').value, debit: Number(tr.querySelector('.jv-debit').value || 0), credit: Number(tr.querySelector('.jv-credit').value || 0) })).filter((line) => line.account && (line.debit > 0 || line.credit > 0));
      const amount = lines.reduce((sum, line) => sum + line.debit, 0);
      const values = { type: 'JV', date: journalVoucherForm.elements.date.value, currency: journalVoucherForm.elements.currency.value, amount, exchangeRate: 1, description: journalVoucherForm.elements.description.value, lines };
      setBusy(true);
      try { await saveDraft(values, member); journalVoucherForm.reset(); journalVoucherForm.elements.date.value = new Date().toISOString().slice(0,10); syncJournalVoucherFields(); updateJvTotals(); message('حُفظ قيد اليومية كمسودة. لا يؤثر في الأرصدة حتى اعتماده وترحيله.', 'success'); }
      catch (error) { message(error.message || 'تعذر حفظ قيد اليومية.'); }
      finally { setBusy(false); }
    });
  }
  const accountsPanel = document.querySelector('#accounts-panel');
  if (accountsPanel) accountsPanel.addEventListener('submit', async (event) => {
    if (event.target.id === 'opening-balance-form') {
      event.preventDefault(); if (busy) return;
      const form = event.target;
      const balances = [...form.querySelectorAll('.opening-amount')]
        .filter((input) => input.value !== '')
        .map((input) => ({ account_code: input.dataset.accountCode, amount: Number(input.value) }));
      if (!balances.length) return message('أدخل رصيد حساب واحد على الأقل.');
      if (balances.some((item) => !Number.isFinite(item.amount) || item.amount <= 0)) return message('تحقق من مبالغ الأرصدة المدخلة.');
      if (!confirm(`سيتم ترحيل أرصدة ${balances.length} حساب/حسابات بقيود افتتاحية لا يمكن تكرارها. هل تريد المتابعة؟`)) return;
      setBusy(true);
      try {
        const result = await setOpeningBalances(balances, form.elements.entryDate.value, form.elements.description.value);
        await refreshLedger();
        message(`تم ترحيل الأرصدة الافتتاحية بنجاح لعدد ${result.count} حساب/حسابات.`, 'success');
      } catch (error) { message(error.message || 'تعذر ترحيل الأرصدة الافتتاحية.'); }
      finally { setBusy(false); }
      return;
    }
    if (event.target.id !== 'account-form') return;
    event.preventDefault(); if (busy) return;
    const fd = new FormData(event.target);
    const input = { accountCode: fd.get('accountCode'), accountName: fd.get('accountName'), accountType: fd.get('accountType'), currency: fd.get('currency'), categoryKey: fd.get('categoryKey'), isCash: fd.get('isCash') === 'on' };
    setBusy(true);
    try { await createLedgerAccount(input); event.target.reset(); await refreshLedger(); message('تمت إضافة الحساب إلى دليل الحسابات.', 'success'); }
    catch (error) { message(error.message || 'تعذرت إضافة الحساب.'); }
    finally { setBusy(false); }
  });
  const periodForm = document.querySelector('#accounting-period-form');
  if (periodForm) periodForm.addEventListener('submit', async (event) => {
    event.preventDefault(); if (busy) return;
    const start = periodForm.elements.start.value; const end = periodForm.elements.end.value; const reason = periodForm.elements.reason.value.trim();
    if (start > end) return message('تاريخ بداية الفترة يجب أن يسبق تاريخ نهايتها.');
    if (!confirm(`سيتم إقفال الفترة من ${start} إلى ${end}. لن يسمح النظام بترحيل أو إلغاء قيود داخلها حتى إعادة فتحها بسبب موثق. هل تريد المتابعة؟`)) return;
    setBusy(true);
    try { await closeAccountingPeriod(start, end, reason); await refreshPeriods(); await refreshAudit(); message('تم إقفال الفترة المحاسبية. تم تفعيل الحماية على مستوى قاعدة البيانات.', 'success'); }
    catch (error) { message(error.message || 'تعذر إقفال الفترة المحاسبية.'); }
    finally { setBusy(false); }
  });
  document.querySelector('#refresh-audit')?.addEventListener('click', refreshAudit);
  const periodsList = document.querySelector('#accounting-periods-list');
  if (periodsList) periodsList.addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-period-action="reopen"]'); if (!button || busy) return;
    const reason = prompt(`أدخل سبب إعادة فتح الفترة ${button.dataset.start} إلى ${button.dataset.end}.` ) || ''; if (reason.trim().length < 5) return;
    if (!confirm('إعادة فتح الفترة تسمح مجدداً بترحيل القيود وإلغاء السندات ضمن نطاقها. هل تؤكد؟')) return;
    setBusy(true);
    try { await reopenAccountingPeriod(button.dataset.start, button.dataset.end, reason); await refreshPeriods(); await refreshAudit(); message('تمت إعادة فتح الفترة مع تسجيل السبب في سجل المراجعة.', 'success'); }
    catch (error) { message(error.message || 'تعذرت إعادة فتح الفترة.'); }
    finally { setBusy(false); }
  });
  const voucherBody = document.querySelector('#voucher-rows');
  if (voucherBody) voucherBody.addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button || busy) return;
    const id = button.dataset.id;
    if (button.dataset.action === 'approve' && !confirm(`هل تريد اعتماد السند ${id} وترحيله إلى دفتر اليومية؟ لا يمكن تعديل السند بعد ذلك.`)) return;
    let reason = '';
    if (button.dataset.action === 'reverse') { reason = prompt(`أدخل سبب إلغاء السند ${id}. سيتم إنشاء قيد عكسي ولن يُحذف القيد الأصلي.`) || ''; if (!reason.trim()) return; }
    setBusy(true);
    try {
      if (button.dataset.action === 'approve') await postVoucher(id);
      else await reverseVoucher(id, reason);
      await Promise.all([getVouchers().then(refresh), refreshLedger()]);
      message(button.dataset.action === 'approve' ? 'تم اعتماد السند وترحيله محاسبياً.' : 'تم إلغاء السند بإنشاء قيد عكسي موثق.', 'success');
    } catch (error) { message(error.message || 'تعذر تنفيذ العملية المحاسبية.'); }
    finally { setBusy(false); }
  });
  const form = document.querySelector('#voucher-form');
  if (form) {
    form.elements.type.addEventListener('change', syncVoucherFields);
    form.elements.currency.addEventListener('change', syncVoucherFields);
    syncVoucherFields();
    form.addEventListener('submit', async (event) => {
    event.preventDefault(); if (busy) return;
    const values = Object.fromEntries(new FormData(form).entries());
    setBusy(true);
    try { await saveDraft(values, member); form.reset(); form.elements.date.value = new Date().toISOString().slice(0,10); form.elements.exchangeRate.value = '1'; message('حُفظ السند كمسودة بنجاح.', 'success'); }
    catch (error) { message(error.message || 'تعذر حفظ السند.'); }
    finally { setBusy(false); }
    });
  }
}

async function loadSession() {
  if (!supabase) return configView();
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) { shell('<main class="auth-card"><h1>تعذر التحقق من الجلسة</h1><p>يرجى تحديث الصفحة والمحاولة مجدداً.</p></main>'); return; }
  if (!session) { member = null; loginView(); return; }
  const { data, error: memberError } = await supabase.from('app_members').select('user_id,role,is_active,display_name,must_change_password').eq('user_id', session.user.id).maybeSingle();
  if (memberError || !data || !data.is_active) {
    await supabase.auth.signOut();
    shell('<main class="auth-card"><h1>لا يوجد تصريح دخول</h1><p class="muted">هذا الحساب غير مفعّل في النظام. يرجى مراجعة مدير النظام.</p><button id="back-login" class="primary">العودة لتسجيل الدخول</button></main>');
    document.querySelector('#back-login').addEventListener('click', loginView);
    return;
  }
  member = data;
  if (member.must_change_password) passwordView(); else dashboardView();
}
function configView() {
  shell('<main class="auth-card"><h1>إعداد الاتصال</h1><p class="muted">لم يتم ضبط إعدادات Supabase في بيئة التشغيل. أضف عنوان المشروع والمفتاح العام في متغيرات البيئة ثم أعد البناء.</p><code>VITE_SUPABASE_URL<br>VITE_SUPABASE_PUBLISHABLE_KEY</code></main>');
}
if (!supabase) configView();
else {
  supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_OUT' && !session) { member = null; loginView(); }
  });
  loadSession();
}
