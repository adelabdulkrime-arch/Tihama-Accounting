import test from 'node:test';
import assert from 'node:assert/strict';
import { validateVoucher } from '../src/data/voucher-validation.js';

const validReceipt = {
  type: 'RV', date: '2026-11-23', amount: 1250, currency: 'YER', exchangeRate: 1,
  party: 'عميل تجريبي', account: '1110', category: 'إيرادات الخدمات', description: 'اختبار سند قبض',
};

test('valid receipt draft passes client-side validation', () => {
  assert.deepEqual(validateVoucher(validReceipt), []);
});

test('receipt without mapped income category is rejected before saving', () => {
  assert.ok(validateVoucher({ ...validReceipt, category: '' }).some((x) => x.includes('بند الإيراد')));
});

test('transfer requires two distinct cash account references', () => {
  const transfer = { ...validReceipt, type: 'TR', fromAccount: '1110', toAccount: '1110' };
  assert.ok(validateVoucher(transfer).some((x) => x.includes('مختلفين')));
});

test('non-positive amounts and unsupported currencies are rejected', () => {
  assert.ok(validateVoucher({ ...validReceipt, amount: 0 }).some((x) => x.includes('أكبر من صفر')));
  assert.ok(validateVoucher({ ...validReceipt, currency: 'EUR' }).some((x) => x.includes('عملة صحيحة')));
});

test('balanced general journal voucher is accepted and unbalanced journal is rejected', () => {
  const journal = {
    ...validReceipt,
    type: 'JV',
    party: '',
    account: '',
    category: '',
    amount: 125,
    lines: [
      { account: 'BANK-KURAIMI-USD', debit: 125, credit: 0 },
      { account: 'EQUITY-OPENING-USD', debit: 0, credit: 125 },
    ],
  };
  assert.deepEqual(validateVoucher(journal), []);
  assert.ok(validateVoucher({ ...journal, lines: [{ ...journal.lines[0], debit: 100 }, journal.lines[1]] }).some((x) => x.includes('غير متوازن')));
});

test('general journal rejects a line with both debit and credit', () => {
  const journal = {
    ...validReceipt,
    type: 'JV', party: '', account: '', category: '', amount: 100,
    lines: [
      { account: 'A', debit: 100, credit: 5 },
      { account: 'B', debit: 0, credit: 95 },
    ],
  };
  assert.ok(validateVoucher(journal).some((x) => x.includes('السطر 1')));
});
