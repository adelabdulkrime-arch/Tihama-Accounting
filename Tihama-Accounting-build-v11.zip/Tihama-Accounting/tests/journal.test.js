import test from 'node:test';
import assert from 'node:assert/strict';
import { buildJournal, buildTrialBalance, journalTotals, projectVoucherToJournal } from '../src/data/journal.js';

const base = { number: 'RV-0001', date: '2026-11-23', currency: 'YER', amount: 1500, description: 'اختبار', status: 'approved' };

test('draft vouchers are never projected into the journal', () => {
  assert.deepEqual(projectVoucherToJournal({ ...base, status: 'draft', type: 'RV', account: 'الصندوق' }), []);
});

test('receipt creates equal debit and revenue credit', () => {
  const lines = projectVoucherToJournal({ ...base, type: 'RV', account: 'الصندوق الرئيسي', category: 'إيرادات الخدمات' });
  assert.equal(lines.length, 2);
  assert.equal(lines[0].debit, 1500);
  assert.equal(lines[1].credit, 1500);
});

test('payment creates expense debit and cash credit', () => {
  const lines = projectVoucherToJournal({ ...base, type: 'PV', account: 'الصندوق الرئيسي', category: 'الإيجارات' });
  assert.equal(lines[0].account, 'مصروف / الإيجارات');
  assert.equal(lines[1].account, 'نقدية / الصندوق الرئيسي');
  assert.equal(lines[0].debit, lines[1].credit);
});

test('internal transfer is not classified as revenue or expense', () => {
  const lines = projectVoucherToJournal({ ...base, type: 'TR', fromAccount: 'الصندوق', toAccount: 'البنك' });
  assert.equal(lines[0].account, 'نقدية / البنك');
  assert.equal(lines[1].account, 'نقدية / الصندوق');
  assert.ok(lines.every((line) => !/إيراد|مصروف/.test(line.account)));
});

test('trial balance is grouped independently by currency', () => {
  const journal = buildJournal([
    { ...base, type: 'RV', account: 'الصندوق', category: 'خدمات' },
    { ...base, number: 'PV-0001', type: 'PV', account: 'الصندوق', category: 'نقل', amount: 500 },
    { ...base, number: 'RV-0002', type: 'RV', account: 'الصندوق السعودي', category: 'خدمات', currency: 'SAR', amount: 100 },
  ]);
  const totals = journalTotals(journal);
  assert.deepEqual(totals.map((x) => x.currency).sort(), ['SAR', 'YER']);
  assert.ok(totals.every((x) => x.balanced));
  assert.ok(buildTrialBalance(journal).some((x) => x.account === 'نقدية / الصندوق' && x.currency === 'YER'));
});

test('invalid transfer and unbalanced journal are rejected', () => {
  assert.throws(() => projectVoucherToJournal({ ...base, type: 'TR', fromAccount: 'نفسه', toAccount: 'نفسه' }));
  assert.throws(() => projectVoucherToJournal({ ...base, type: 'JV', lines: [{ account: 'الصندوق', debit: 100, credit: 0 }, { account: 'إيراد', debit: 0, credit: 90 }] }));
});


test('balanced general journal lines are retained as entered', () => {
  const lines = projectVoucherToJournal({ ...base, type: 'JV', lines: [
    { account: 'مصروف / نقل', debit: 300, credit: 0 },
    { account: 'نقدية / الصندوق', debit: 0, credit: 300 },
  ] });
  assert.equal(lines.length, 2);
  assert.equal(lines.reduce((n, line) => n + line.debit, 0), 300);
  assert.equal(lines.reduce((n, line) => n + line.credit, 0), 300);
});
