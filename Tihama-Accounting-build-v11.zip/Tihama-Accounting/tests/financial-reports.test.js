import test from 'node:test';
import assert from 'node:assert/strict';
import { buildBalanceSheet, buildGeneralLedger, buildIncomeStatement, buildTrialBalance } from '../src/data/financial-reports.js';

const accounts = [
  { id: 'cash', account_code: '1000', account_name: 'الصندوق', account_type: 'asset', currency: 'YER' },
  { id: 'payable', account_code: '2000', account_name: 'الموردون', account_type: 'liability', currency: 'YER' },
  { id: 'capital', account_code: '3000', account_name: 'رأس المال', account_type: 'equity', currency: 'YER' },
  { id: 'revenue', account_code: '4000', account_name: 'الإيرادات', account_type: 'revenue', currency: 'YER' },
  { id: 'expense', account_code: '5000', account_name: 'المصروفات', account_type: 'expense', currency: 'YER' },
  { id: 'usd-cash', account_code: '1100', account_name: 'الصندوق دولار', account_type: 'asset', currency: 'USD' },
  { id: 'usd-capital', account_code: '3100', account_name: 'رأس المال دولار', account_type: 'equity', currency: 'USD' },
];
const line = (account, debit, credit, currency = 'YER', line_number = 1) => ({ account_id: account, account: accounts.find((item) => item.id === account), debit, credit, currency, line_number });
const entries = [
  { id: 'opening', entry_number: 1, entry_date: '2026-01-01', status: 'posted', lines: [line('cash', 1000, 0), line('capital', 0, 1000, 'YER', 2)] },
  { id: 'sale', entry_number: 2, entry_date: '2026-01-10', status: 'posted', lines: [line('cash', 500, 0), line('revenue', 0, 500, 'YER', 2)] },
  { id: 'expense', entry_number: 3, entry_date: '2026-01-12', status: 'posted', lines: [line('expense', 200, 0), line('cash', 0, 200, 'YER', 2)] },
  { id: 'draft', entry_number: 4, entry_date: '2026-01-15', status: 'draft', lines: [line('cash', 900, 0), line('revenue', 0, 900, 'YER', 2)] },
  { id: 'reversed-original', entry_number: 5, entry_date: '2026-01-18', status: 'reversed', lines: [line('cash', 100, 0), line('revenue', 0, 100, 'YER', 2)] },
  { id: 'reversal', entry_number: 6, entry_date: '2026-01-19', status: 'posted', entry_kind: 'reversal', lines: [line('cash', 0, 100), line('revenue', 100, 0, 'YER', 2)] },
  { id: 'usd', entry_number: 7, entry_date: '2026-01-20', status: 'posted', lines: [line('usd-cash', 50, 0, 'USD'), line('usd-capital', 0, 50, 'USD', 2)] },
];

test('trial balance excludes drafts, nets reversals, and keeps currencies separate', () => {
  const result = buildTrialBalance(accounts, entries, '2026-01-31');
  const yer = result.totals.find((row) => row.currency === 'YER');
  const usd = result.totals.find((row) => row.currency === 'USD');
  assert.equal(yer.debit, 1500);
  assert.equal(yer.credit, 1500);
  assert.equal(usd.debit, 50);
  assert.equal(usd.credit, 50);
  assert.equal(result.rows.find((row) => row.accountId === 'revenue').credit, 500);
});

test('income statement includes only posted movements in the selected period', () => {
  const result = buildIncomeStatement(accounts, entries, '2026-01-01', '2026-01-31', 'YER');
  assert.deepEqual(result.totals, [{ currency: 'YER', revenue: 500, expenses: 200, netProfit: 300 }]);
});

test('balance sheet balances with accumulated current earnings by currency', () => {
  const result = buildBalanceSheet(accounts, entries, '2026-01-31');
  const yer = result.totals.find((row) => row.currency === 'YER');
  const usd = result.totals.find((row) => row.currency === 'USD');
  assert.equal(yer.assets, 1300);
  assert.equal(yer.totalEquityAndLiabilities, 1300);
  assert.equal(yer.difference, 0);
  assert.equal(usd.assets, 50);
  assert.equal(usd.totalEquityAndLiabilities, 50);
  assert.equal(usd.difference, 0);
});

test('general ledger calculates opening, running and closing balances', () => {
  const result = buildGeneralLedger(accounts, entries, 'cash', '2026-01-10', '2026-01-31');
  assert.equal(result.openingBalance, 1000);
  assert.deepEqual(result.rows.map((row) => row.balance), [1500, 1300, 1400, 1300]);
  assert.equal(result.closingBalance, 1300);
});
