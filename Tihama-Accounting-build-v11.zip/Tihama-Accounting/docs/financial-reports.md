# Financial reports — v11

## Source of truth
All report calculations consume `journal_entries` and their associated `journal_lines`, joined to `ledger_accounts`. No report reads draft voucher payloads. The ledger schema only accepts posted journal entries and reversal entries; entries marked `reversed` are retained alongside their corresponding posted reversal entry so the accounting effect nets to zero while the audit trail remains intact.

## Currency treatment
Every report groups by the currency recorded on the journal line and matching ledger account. YER, SAR, USD and additional configured currencies are never added together and no implicit conversion rate is applied.

## Reports
- **Trial balance:** cumulative debit/credit-normal account balances as of the selected date, shown separately for each currency.
- **Income statement:** revenue and expense movements between the selected start and end dates, with net profit/loss by currency.
- **Balance sheet:** asset, liability and equity balances as of the selected date. Until formal closing entries are implemented, accumulated net income is calculated from posted revenue and expense balances and shown as a separate retained-earnings line.
- **General ledger:** account-level transactions within the selected period, opening balance before the start date, chronological running balance and closing balance.

## Reversal treatment
The original journal entry is marked `reversed` and a separate reversal entry is posted with debit and credit swapped. Both are included in report calculations. Excluding the reversed original while retaining its reversal would incorrectly create an opposite balance; therefore both remain in the ledger view and net to zero.

## Known limitations
- Payroll, advances, settlement, custody and fixed-asset workflows are not yet posted to the general ledger; their amounts are not included in these reports.
- Formal year-end closing entries and profit-and-loss transfer to retained earnings are not implemented. The balance sheet derives accumulated net income until that workflow exists.
- No foreign-exchange translation, consolidation, or realized/unrealized FX gains/losses are calculated.
- Browser-level Supabase verification and production build are still required before deployment.
