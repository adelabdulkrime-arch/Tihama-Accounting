# التدقيق الفني للملف الأصلي

## ما تم فحصه
- الملف الأصلي: `Tihama_Accounting_Netlify_Preparation.html`، حجم 94,467 بايت، 295 سطراً.
- يحتوي على واجهة عربية RTL ووحدات محاسبية متعددة ضمن ملف HTML/JavaScript واحد.
- الاعتماد الخارجي الواضح يشمل مكتبة QR ومكتبة XLSX من jsDelivr.
- نقاط Claude المباشرة التي ظهرت في الشيفرة: `claude.use('user')` و`claude.use('db')` ومرتان `claude.use('assets')`.
- طبقة البيانات الحالية تستعمل نمطاً شبيهاً بـ Firestore: `doc().set`, `collection().onSnapshot`, وعمليات قراءة/كتابة حسب أسماء مجموعات.

## الوحدات المرصودة
- سندات قبض وصرف وتحويل داخلي وقيود وتسويات.
- سجل السندات والبحث والتقارير والأستاذ وميزان المراجعة.
- المرشحون والعملاء والملفات والمرفقات والاستيراد من Excel/CSV.
- الموظفون وكشوف الرواتب والسلف والعهد.
- الأصول والإعدادات وسجل المراجعة.

## مخاطر يجب معالجتها قبل نشر نسخة عامة
1. يحتوي الملف الأصلي على أرقام حسابات بنكية ومحافظ ثابتة ضمن الإعدادات الافتراضية. لا تنشر هذه القيم كما هي.
2. يحتوي على بيانات اتصال وعناوين وأرقام هاتف وبريد وروابط تخص الجهة؛ يجب اعتماد ما يجوز نشره قبل إدراجها في نسخة عامة.
3. واجهة العرض تهيئ `S.adm=true` و`S.ed=true` افتراضياً في الذاكرة. لا يجوز اعتبار صلاحيات الواجهة تفويضاً أمنياً؛ يجب أن تكون جميع العمليات الحساسة محمية بسياسات RLS.
4. يوجد مسار عرض تجريبي/ذاكرة محلية عند غياب قاعدة البيانات؛ يجب منع هذا المسار في بيئة الإنتاج حتى لا تبدو العمليات وكأنها حُفظت.
5. بعض أحداث سجل التدقيق الحالية لا تضمن الكتابة إذا لم تتوفر قاعدة البيانات؛ يلزم سجل تدقيق خادمي غير قابل للتلاعب من العميل.
6. رفع الملفات يعتمد على Claude Assets ويجب نقله إلى bucket خاص في Supabase Storage بسياسات قراءة وكتابة مناسبة.
7. يجب مراجعة التحقق من أرقام السندات والتكرار والاعتماد والإلغاء والترحيل المحاسبي قبل تحويل كل عملية إلى قاعدة البيانات.

## خطة الترحيل الآمنة
1. جرد كل شكل بيانات مستخدم في المجموعات: vouchers, emps, sal, adv, cus, fa, close, par, reg, audit, settings, keys.
2. تصميم مخطط PostgreSQL يحافظ على المعرفات والعلاقات والحقول مع قيود فريدة ومفاتيح خارجية حيث يلزم.
3. تطبيق RLS لكل جدول حسب الدور والملكية والنطاق، لا الاكتفاء بشرط authenticated.
4. اعتماد جدول العضوية الحالي `app_members` كمصدر الدور، وعدم الاعتماد على user_metadata في التفويض.
5. تنفيذ تسجيل الدخول بالبريد أولاً. دعم اسم المستخدم يحتاج lookup آمن من جهة خادمية دون كشف بريد الحسابات أو تخزين كلمات المرور في جدول عام.
6. فرض تغيير كلمة المرور الأولي عبر Supabase Auth ثم استدعاء دالة إكمال الإعداد الحالية بعد نجاح التغيير.
7. نقل المرفقات إلى bucket خاص وربطها بسجلاتها، مع روابط موقعة قصيرة العمر عند الحاجة.
8. اختبارات مطابقة: رصيد كل حساب، أرصدة العملات، عدم ازدواج الصرف، التحويل الداخلي، الرواتب والسلف، اعتماد/إلغاء السند، صلاحيات المستخدم، سجل التدقيق، واستعادة المرفقات.
9. لا تُستورد بيانات حقيقية ولا يُفعّل الإنتاج قبل اعتماد نتائج الاختبارات.

## الحالة الحالية
هذا المستودع المحلي يحتوي على هيكل إعداد آمن أولي فقط. لم تُنقل الوحدات المحاسبية بعد، ولم يتم رفع الملفات إلى GitHub بسبب رفض صلاحية الكتابة (HTTP 403 من تكامل GitHub).

## Authentication verification and current security-advisor findings (2026-11-23)
- Confirmed administrator membership still exists: active admin, display name `مدير النظام`, `must_change_password=true`.
- Confirmed `complete_own_password_setup()` checks `auth.uid()`, updates only the caller's active membership, and has an empty `search_path`. It is intentionally called after Auth password update. The SECURITY DEFINER warning remains visible and must be reviewed rather than blindly changing it to INVOKER (the member's own-row UPDATE policy is not present).
- Supabase Security Advisor currently reports three SECURITY DEFINER RPC exposure warnings (`complete_own_password_setup`, `has_app_role`, `is_active_app_member`) and one warning that leaked-password protection is disabled. These are documented; no database security change was made in this step.
- Review the functions' grants and behavior before production. Enable leaked-password protection in Supabase Auth password-security settings.

## Live Supabase verification — 2026-11-23
- The dedicated `Tihama-Accounting` Supabase project is currently `ACTIVE_HEALTHY`.
- Read-only database check found 12 ledger accounts, 0 journal entries, 0 journal lines and 0 voucher records at the time of inspection. The financial-report functions therefore have no live transaction data to reconcile yet; their calculation logic is covered by isolated unit tests.
- Security Advisor currently reports 10 authenticated-callable `SECURITY DEFINER` functions. The privileged posting, reversal, account, opening-balance, period and audit functions are intended to be admin-gated inside their function bodies; these warnings still require a final grant/body review before production.
- Security Advisor also reports leaked-password protection disabled. Enable it in Supabase Auth before real-user production access.
- `private.audit_events` has RLS enabled without a policy. This is intentional only while the schema remains non-exposed and access is exclusively mediated through the guarded audit RPC; verify that the `private` schema is not exposed through the Data API.
- No live database changes were made during this inspection.
