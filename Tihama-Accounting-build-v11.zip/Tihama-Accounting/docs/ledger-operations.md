# Ledger posting rules and remaining reconciliation

## Current supported voucher mapping

| Voucher | Debit | Credit | Preconditions |
|---|---|---|---|
| RV receipt | Active cash/bank/wallet account | Active revenue account mapped to the exact voucher category | Same currency; category mapping exists |
| PV payment | Active expense account mapped to the exact voucher category | Active cash/bank/wallet account | Same currency; category mapping exists |
| TR internal transfer | Receiving cash account | Sending cash account | Both cash accounts use the voucher currency |
| JV general journal | User-entered debit lines | User-entered credit lines | At least two lines; every account exists in same currency; totals balance |

Every posting call runs in one PostgreSQL transaction. A failed validation rolls back the header, lines, voucher state change and audit event together. An `app_records` trigger also records create/update/delete metadata (changed JSON key names and status only, not full payload contents) in the private audit schema. The voucher row is locked during posting, and the unique source reference prevents duplicate journal entries.

## Reversal

An approved voucher can be reversed only by an active admin and only with a non-empty reason. The original entry and lines remain intact. A separate reversal entry is created with debit and credit swapped line-by-line; the original header is marked `reversed`, and the voucher is marked `cancelled` with the reversal reference and reason.

## Required before production

1. Import the real chart of accounts only after reviewing the original `DEF.accts` and settings data; never import bank account numbers into public source files.
1. Reconcile the entered opening balances against dated bank and wallet statements before any production posting.
2. Add closed-period controls to both posting and reversal.
3. Add cross-currency transfer and FX clearing/realized gain-loss logic; currently cross-currency transfers are rejected.
4. Add posting support for settlement, payroll, advances, custody and fixed assets.
5. Add a server-side immutable audit viewer/export and secure private Storage attachments.
6. Reconcile every migrated record against the legacy reports before switching production users.

## الحسابات البنكية ومحفظة جيب والأرصدة الافتتاحية
- لكل عملة حساب مستقل في دفتر الأستاذ؛ لا تجمع مبالغ USD وSAR وYER في رصيد واحد.
- بيانات الحساب البنكي الخارجية محفوظة في حقول `institution_name` و`external_account_number`، والرقم البديل لمحفظة جيب في `alternate_reference`.
- الأرصدة الافتتاحية لم تُحدد بعد، ولذلك لا يزال رصيد كل حساب صفراً.
- توجد شاشة لمدير النظام لإدخال الأرصدة غير المسجلة. تحفظ قاعدة البيانات كل رصيد بقيد افتتاحي مستقل مقابل حساب حقوق الملكية المطابق للعملة، وتمنع التكرار.
- أضيف مشغل قاعدة بيانات يمنع إدخال أي سطر دائن على حساب نقدي إذا أدى إلى رصيد سالب. يطبق ذلك على سندات الصرف والتحويلات والعكوسات أيضاً.

## قيد اليومية العام
- يسمح القيد بسطرين على الأقل، ويشترط وجود حساب صالح ونفس العملة في كل سطر.
- يمنع الجمع بين المدين والدائن في السطر الواحد، ويشترط أن يتساوى مجموع المدين والدائن.
- مبلغ السند يساوي مجموع المدين؛ الحفظ ينشئ مسودة فقط، والترحيل يتم عبر RPC محمي في قاعدة البيانات.


## Accounting period closing

- Only an active system administrator can close or reopen a period.
- Closing is rejected when a draft voucher exists in the date range, when a posted journal entry is incomplete/unbalanced, or when the range overlaps another closed period.
- A database trigger blocks all new journal entries dated inside a closed period, including voucher posting and opening-balance posting. The trigger and close/reopen RPCs serialize through the same transaction advisory lock to avoid a close-vs-post race.
- Reversing a voucher whose original entry belongs to a closed period is rejected until the period is reopened with a reason.
- Close and reopen events are recorded in the server-side audit table. Reopening does not erase the previous close record; it changes its state and records who reopened it and why.
