# Validation checklist before production

## Authentication
- [ ] Sign in using the administrator's registered email.
- [ ] Verify a non-member is signed out and cannot enter the workspace.
- [ ] Verify inactive membership is denied.
- [ ] Verify `must_change_password=true` blocks all workspace routes.
- [ ] Change password and verify the RPC clears the flag only for `auth.uid()`.
- [ ] Verify a regular login after password setup opens the workspace.

## Authorization
- [ ] Test admin, editor, viewer, inactive, and unauthenticated sessions.
- [ ] Verify all authorization is enforced by RLS, not by UI state.
- [ ] Review `has_app_role` and `is_active_app_member` definitions and advisors.
- [ ] Restrict sensitive settings and audit data before enabling real users.

## Accounting regression
- [ ] Receipt, payment, internal transfer, journal entry, and settlement.
- [ ] Unique voucher numbering and duplicate submission protection.
- [ ] Posting, reversal, approval, and cancellation behavior.
- [ ] Trial balance and ledger reconcile to source data.
- [ ] Payroll, advances, custody, fixed assets, and closing.
- [ ] Excel import/export and attachment access controls.

## Release
- [ ] Add real project URL and publishable key only as deployment environment variables.
- [ ] Never add service-role or secret keys to VITE_ variables or Git.
- [ ] Run dependency audit and production build with committed lockfile.
- [ ] Verify Netlify preview, redirects, Auth redirect URLs, and Storage policies.
- [ ] Back up database and approve a restore test.

## Voucher module — first migration slice

- [x] Add an explicit voucher payload schema version (`schemaVersion: 1`).
- [x] Validate voucher type, date, currency, positive amount, party/account fields and transfer account separation before save.
- [x] Persist voucher drafts in `public.app_records` under collection `vouchers`.
- [x] Generate collision-resistant draft identifiers without relying on a client-side sequential counter.
- [x] Display persisted vouchers and subscribe to Realtime changes.
- [x] Keep viewer role read-only in the interface; database RLS remains the actual enforcement layer.
- [x] Add a server-side atomic approval RPC with row locking, account mapping validation, balanced lines and duplicate-posting protection.
- [x] Add journal-entry and journal-line tables with direct client writes revoked.
- [x] Add a server-side reversal RPC; original journal lines are retained and reversed by a separate entry.
- [x] Add chart-of-accounts records and selectable account references with server-side currency matching.
- [ ] Run browser integration tests against a non-production Supabase project before enabling approval.

**Current boundary:** posting and reversal are now enabled for administrators for RV/PV/TR vouchers after chart-of-accounts mapping. Cash balance/overdraft controls, opening balances, cross-currency transfer, period locks and the JV editor remain pending. No production release is authorized yet.

## Journal preview and draft immutability — 2026-11-23
- [x] Add read-only journal projection for approved receipt/payment/transfer/journal vouchers.
- [x] Exclude drafts and cancelled vouchers from the journal projection.
- [x] Validate journal lines and balance totals independently per currency.
- [x] Add trial-balance preview grouped by account and currency.
- [x] Add automated unit tests for receipt, payment, transfer, currency grouping and invalid/unbalanced journals.
- [x] Apply and verify RLS policy conditions so voucher inserts must be drafts and only draft vouchers can be directly updated/deleted.
- [x] Implement transactional approval RPC with voucher row lock, unique source reference and balanced-line checks.
- [x] Implement journal-entry tables and a server-side reversal/cancellation workflow.
- [x] Replace free-text cash accounts with chart-of-accounts selections and server-side currency constraints.
- [ ] Verify the policy behavior with authenticated admin/editor/viewer sessions in a browser integration test.

**Important:** the journal is a projection for review only. It does not post to a general ledger or change account balances. Existing original HTML records use a different field naming convention and are not automatically migrated by this release.


## Ledger posting and audit — 2026-11-23
- [x] Create `ledger_accounts`, `journal_entries`, `journal_lines` with RLS enabled.
- [x] Revoke direct client-side journal inserts/updates/deletes; active members receive read-only access.
- [x] Restrict account creation, posting and reversal to an active admin checked against `app_members` inside database functions.
- [x] Prevent duplicate category mappings per account type and currency.
- [x] Add atomic receipt/payment/transfer posting; reject missing mappings and currency mismatches.
- [x] Add reversal entries with mandatory reason; preserve original journal lines.
- [x] Add a private audit trigger on `app_records`; audit stores changed JSON keys and status metadata, not full record payloads.
- [x] Run rollback-only Supabase integration test for account creation, posting and reversal; confirm test rows were rolled back.
- [x] Verify `anon` cannot execute privileged RPCs and authenticated users cannot directly write journal tables.
- [ ] Add opening-balance journal workflow and reconcile imported balances.
- [ ] Add cash-balance validation, overdraft exception process and closed-period controls.
- [ ] Add FX transfer accounting and realized/unrealized exchange differences.
- [ ] Add dedicated JV form and migrate settlement/payroll/advances/assets/closing logic.
- [ ] Complete browser-level tests and production build; npm registry access timed out during this pass.


## Accounting period controls
- [x] Active admin can close a date range with a documented reason.
- [x] Closing is rejected if a draft voucher exists within the selected dates.
- [x] Closing is rejected if a journal entry has fewer than two lines or is unbalanced.
- [x] Overlapping closed periods are rejected.
- [x] A database trigger rejects journal-entry inserts in a closed period.
- [x] Reversal of an original entry in a closed period is rejected.
- [x] Reopening requires an admin and a reason; close/reopen events are audited.
- [x] Rollback-only integration test: close -> blocked journal insert -> reopen -> journal insert allowed -> rollback.

## v10 audit viewer verification
- [x] Admin-only audit RPC checks the active database membership and role.
- [x] RPC pagination bounds: 1–100 rows and non-negative offset.
- [x] Anonymous execute permission revoked.
- [x] Rollback-only integration test confirms an administrator can read an inserted audit event.
- [x] Client UI escapes audit details before rendering and displays metadata only.
- [ ] Browser-level verification remains pending.

## Financial statements and detailed ledger — v11
- [x] Add income statement from posted ledger movements for a selected date range.
- [x] Add balance sheet as of a selected date, including accumulated net income until formal closing entries are implemented.
- [x] Add trial balance as of a selected date, grouped by account and currency.
- [x] Add detailed general ledger by account with opening, running and closing balances.
- [x] Exclude draft/unposted entries from all reports.
- [x] Include the reversal entry together with the reversed original so their net effect is zero while retaining the audit trail.
- [x] Keep YER, SAR, USD and any configured currency in separate report sections; do not convert or combine totals.
- [x] Add automated tests for draft exclusion, reversal netting, currency isolation, income statement, balance sheet and running ledger balance.
- [ ] Browser-level verification against a configured Supabase test project remains pending.
- [ ] Production build remains pending because dependency installation could not complete while npm registry access timed out.
