# Tihama Accounting

مشروع مستقل لإعادة بناء نظام Tihama Vision المحاسبي ونقل تشغيله من تكامل Claude إلى Supabase.

> الحالة: أساس محاسبي أولي مع دليل حسابات وقيود يومية واعتماد/عكس خادمي للسندات المدعومة. لا يزال غير جاهز للإنتاج أو النشر.

## المتطلبات
- Node.js 20+
- حساب Supabase الحالي الخاص بمشروع Tihama-Accounting
- حساب Netlify للنشر

## التشغيل المحلي
1. انسخ `.env.example` إلى `.env`.
2. أدخل عنوان Supabase والمفتاح Publishable فقط.
3. ثبّت الاعتماديات: `npm install`
4. شغّل: `npm run dev`

## الأمان
- لا تضع كلمات مرور أو مفاتيح سرية أو بيانات مالية حقيقية في Git.
- مسموح في المتصفح استخدام Supabase Publishable Key فقط.
- يمنع استخدام `service_role` أو Secret Key في الواجهة أو متغيرات `VITE_*`.
- كل الجداول المكشوفة يجب أن تستخدم RLS وسياسات تفويض دقيقة.
- المرفقات يجب أن تكون في bucket خاص بسياسات وصول مقيّدة.

## نطاق النقل
راجع `docs/technical-audit.md` قبل تنفيذ النقل. لا تُحذف الوظائف الأصلية ولا يُعتمد أي ترحيل بيانات قبل اختبارات المطابقة.

## Progress (2026-11-23)
- Implemented browser sign-in with Supabase email/password.
- Implemented active-membership and database-role verification before showing the workspace.
- Implemented mandatory first-login password change using Supabase Auth and the existing `complete_own_password_setup()` RPC.
- Added a typed-by-contract data access module for the existing `app_records` JSONB store, including CRUD and Realtime refresh.
- Deliberately excluded client-side writes to `audit` and access to `keys` until dedicated secure designs are implemented.
- The legacy workflows are still being ported and require reconciliation against the original HTML before full production use.

## Voucher and ledger implementation (2026-11-23)
- Receipt, payment and internal-transfer vouchers are saved as drafts in `public.app_records`.
- Added a dedicated `public.ledger_accounts` chart with account code, name, classification, currency, cash-account flag and optional revenue/expense category mapping.
- Account creation is performed through the admin-only `create_ledger_account()` database function; ordinary authenticated clients cannot directly insert/update/delete ledger rows.
- Added `public.journal_entries` and `public.journal_lines` with RLS enabled. Authenticated active members can read; direct client-side writes are revoked.
- Added atomic admin-only `post_voucher()` RPC. It locks the voucher row, requires draft status, checks the chart-of-accounts mappings, inserts a balanced journal entry and lines, updates voucher status and writes a private audit event in one database transaction.
- Added `reverse_voucher()` RPC. It does not delete or edit the original journal lines; it creates a separate reversing entry, marks the original entry reversed, updates voucher status and records the reason.
- The dashboard now includes chart-of-accounts setup, posting actions for admins, reversal actions with mandatory reason, journal totals and a trial-balance view sourced from the database ledger. A server-side trigger records record create/update/delete metadata without copying sensitive payload contents into the audit log.
- Posting currently supports same-currency RV, PV and TR vouchers. TR across different currencies is deliberately rejected until foreign-exchange clearing and realized/unrealized gain/loss accounts are designed.
- JV posting is supported by the database function and the dashboard includes a multi-line general-journal draft form with client-side balance checks; posting remains admin-only.
- Added an admin-only atomic opening-balance workflow. It posts one balanced journal entry per cash/bank/wallet account against the matching currency opening-equity account, rejects duplicate openings, and records an audit event. The dashboard exposes the workflow for cash accounts that do not yet have an opening entry.
- ST, payroll, employee advances, fixed assets, period closing, FX differences and legacy imports are not yet posted to the ledger.

## Database migrations
- `20261123020000_protect_voucher_drafts.sql`
- `20261123020400_create_accounting_ledger_and_atomic_voucher_posting.sql`
- `20261123020500_add_admin_account_creation_rpc.sql`
- `20261123020600_enforce_unique_ledger_category_mapping.sql`
- `20261123020700_add_server_side_record_audit_and_journal_amount_guard.sql`
- `20261123020800_add_bank_and_wallet_accounts.sql`
- `20261123020900_prevent_negative_cash_balances.sql`
- `20261123021000_add_opening_balance_equity_accounts.sql`
- `20261123021100_add_atomic_opening_balance_posting.sql`
- `20261123021200_allow_opening_journal_entry_kind.sql`
- `20261123021300_protect_opening_balance_from_prior_activity.sql`
- `20261123021400_add_accounting_period_locking.sql`

## Verification and known limitations
- 13 Node unit tests pass; JavaScript syntax checks pass. A rollback-only Supabase integration test confirmed opening balances post as balanced two-line entries and duplicate submissions are rejected.
- A rollback-only database integration test exercised account creation, voucher posting and reversal using the existing administrator identity. It verified that a two-line reversing entry is created; the transaction was rolled back and test accounts/vouchers/entries were confirmed absent afterward.
- Verified that `authenticated` cannot directly INSERT journal entries or UPDATE journal lines, and `anon` cannot execute the privileged RPC functions.
- Supabase Security Advisor flags the three new admin-gated `SECURITY DEFINER` RPCs alongside the pre-existing password/role functions. Each new function checks `auth.uid()` against an active `app_members` row with `role='admin'`, has an empty `search_path`, and is not executable by `anon`. These warnings remain visible and should be reviewed as part of the security sign-off.
- Supabase also reports leaked-password protection disabled; this setting remains to be enabled in the Auth dashboard.
- `npm run build` has not been verified because the npm registry timed out and Vite is not installed in this environment. Do not publish this package as production-ready.
- GitHub upload and Netlify deployment have not been completed.

The original HTML contains legacy account IDs, account names, categories, opening balances, salary, custody, asset and closing-period logic. These must be migrated through explicit mapping and reconciliation. Sensitive bank account numbers and old organization contact details must not be copied into the new public repository.

## الحسابات البنكية والمحافظ
أضيفت حسابات بنك الكريمي وبنك اليمن والكويت YKB ومحفظة جيب إلى دليل الحسابات، مع سجل منفصل لكل عملة (USD / SAR / YER). تحفظ أرقام الحسابات والرقم البديل لمحفظة جيب في حقول مرجعية مستقلة، ولا تُخلط أرصدة العملات. الأرصدة الافتتاحية لم تُفترض أو تُسجل؛ تبدأ الحسابات بصفر. أضيفت شاشة إدارية لإدخال أرصدة الحسابات النقدية غير المسجلة وترحيلها ذرياً كقيود افتتاحية مقابل حساب حقوق الملكية المناسب لكل عملة، مع منع التكرار.

أضيفت حماية على مستوى قاعدة البيانات تمنع ترحيل أي حركة تؤدي إلى رصيد نقدي سالب. لذلك يجب تسجيل الأرصدة الافتتاحية الفعلية أولاً قبل اعتماد سندات الصرف أو التحويل الصادر من حساب لا يملك رصيداً كافياً.

## قيد اليومية العام
تتيح الواجهة إنشاء مسودة قيد يومية عام من عدة أسطر، وتتحقق من الحسابات والعملة وتوازن إجمالي المدين والدائن قبل الحفظ. يظل القيد مسودة ولا يؤثر في الأرصدة إلا بعد اعتماده وترحيله من مدير النظام.

## الأرصدة الافتتاحية
تتيح الواجهة لمدير النظام إدخال الأرصدة الافتتاحية للحسابات النقدية غير المسجلة فقط. تنفذ قاعدة البيانات العملية في معاملة واحدة، وتنشئ قيداً متوازناً لكل حساب مقابل حساب حقوق الملكية المطابق للعملة، وتمنع إعادة تسجيل الحساب ذاته. اختُبر المسار تجريبياً داخل معاملة تم التراجع عنها؛ لم يتم تسجيل أرصدة فعلية في الحسابات حتى الآن.


## إقفال الفترات المحاسبية
تتيح لوحة مدير النظام تحديد بداية ونهاية الفترة وإدخال سبب الإقفال. ترفض قاعدة البيانات الإقفال عند وجود سندات مسودة ضمن الفترة أو قيود غير متوازنة/ناقصة، وترفض نطاقاً يتداخل مع فترة مغلقة أخرى. بعد الإقفال يمنع Trigger خادمي إدخال أي قيد بتاريخ داخل النطاق، كما يمنع إلغاء سند يعود قيده الأصلي إلى فترة مغلقة. يمكن إعادة فتح الفترة لمدير النظام فقط مع تسجيل سبب مستقل في سجل المراجعة. استُخدم قفل معاملات مشترك لمنع حدوث سباق بين عملية الترحيل وعملية الإقفال.

## Admin audit viewer (v10)
- The dashboard now includes an administrator-only audit viewer backed by `public.get_audit_events(limit, offset)`.
- The RPC checks `auth.uid()` against an active `app_members` row with role `admin`, caps page size at 100, and returns event metadata without exposing voucher payloads or raw credentials.
- Direct `anon` execution is revoked. Audit records remain in the unexposed `private.audit_events` schema; the client cannot insert, update, or delete them.
- The dashboard loads the latest 50 events and can refresh after period close/reopen operations.
- Validation: admin RPC returned a rollback-only test event; anon execute privilege is false; all 13 Node tests and JavaScript syntax checks passed.

## Financial reporting — v11
- Added a date-filtered income statement based on posted journal lines only.
- Added a balance sheet as of a selected date. Until formal year-end closing entries are implemented, accumulated net income is presented separately as retained earnings derived from posted revenue and expense accounts.
- Added a trial balance and detailed account ledger with opening, running and closing balances.
- Draft vouchers are never included. Reversed original entries remain visible with their posted reversal entries so the two sides net to zero without erasing history.
- YER, SAR, USD and additional configured currencies are calculated and displayed independently; the application does not add unlike currencies or convert them for these statements.
- Four new unit tests cover financial statements, reversals, date windows and running balances. Total Node unit tests: 17 passing.
- Browser verification and production build remain pending; `npm install` could not complete because registry access timed out. Do not deploy this build as production-ready until dependencies install, the production build succeeds, and a configured Supabase browser test is completed.

## Public-source hygiene
- `.env.example` contains placeholders only. Real Supabase URL/key values must be configured as private deployment environment variables.
- Real bank and wallet account numbers are deliberately excluded from migrations and source control. Existing values already stored in the private Supabase database are not changed by this source cleanup.
- The rollback-only SQL integration test uses an all-zero UUID placeholder; replace it locally with a dedicated test administrator UUID before execution.
