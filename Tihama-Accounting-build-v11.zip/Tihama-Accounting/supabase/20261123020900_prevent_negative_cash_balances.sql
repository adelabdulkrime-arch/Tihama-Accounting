create or replace function private.enforce_nonnegative_cash_balance()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_is_cash boolean;
  v_opening numeric(20,2);
  v_balance numeric(20,2);
begin
  select a.is_cash, a.opening_balance
    into v_is_cash, v_opening
  from public.ledger_accounts a
  where a.id = new.account_id and a.currency = new.currency and a.is_active;

  if not found then
    raise exception 'الحساب المالي غير نشط أو عملته لا تطابق عملة القيد.';
  end if;

  if v_is_cash and new.credit > 0 then
    select coalesce(sum(l.debit - l.credit), 0) + coalesce(v_opening, 0)
      into v_balance
    from public.journal_lines l
    where l.account_id = new.account_id and l.currency = new.currency;

    if v_balance + new.debit - new.credit < -0.005 then
      raise exception 'الرصيد النقدي غير كافٍ في الحساب %. الرصيد المتاح: % %، والمبلغ المطلوب صرفه: % %.',
        new.account_id, round(v_balance,2), new.currency, round(new.credit-new.debit,2), new.currency;
    end if;
  end if;
  return new;
end;
$$;

revoke all on function private.enforce_nonnegative_cash_balance() from public, anon, authenticated;
drop trigger if exists enforce_nonnegative_cash_balance on public.journal_lines;
create trigger enforce_nonnegative_cash_balance
before insert on public.journal_lines
for each row execute function private.enforce_nonnegative_cash_balance();
