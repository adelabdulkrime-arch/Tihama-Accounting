create unique index if not exists ledger_category_mapping_unique
on public.ledger_accounts(category_key, account_type, currency)
where category_key is not null;
