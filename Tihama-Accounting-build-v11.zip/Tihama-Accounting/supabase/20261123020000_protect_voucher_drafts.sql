-- Applied to the dedicated Tihama-Accounting Supabase project on 2026-11-23.
-- Approved vouchers are immutable through direct PostgREST table operations.
-- Approval/reversal must be implemented as a dedicated transactional RPC.
drop policy if exists "editors and admins can insert accounting records" on public.app_records;
create policy "editors and admins can insert accounting records"
on public.app_records for insert to authenticated
with check (
  public.has_app_role(array['admin','editor']::text[])
  and (collection <> 'vouchers' or payload->>'status' = 'draft')
);

drop policy if exists "editors and admins can update accounting records" on public.app_records;
create policy "editors and admins can update accounting records"
on public.app_records for update to authenticated
using (
  public.has_app_role(array['admin','editor']::text[])
  and (collection <> 'vouchers' or payload->>'status' = 'draft')
)
with check (
  public.has_app_role(array['admin','editor']::text[])
  and (collection <> 'vouchers' or payload->>'status' = 'draft')
);

drop policy if exists "admins can delete accounting records" on public.app_records;
create policy "admins can delete accounting records"
on public.app_records for delete to authenticated
using (
  public.has_app_role(array['admin']::text[])
  and (collection <> 'vouchers' or payload->>'status' = 'draft')
);
