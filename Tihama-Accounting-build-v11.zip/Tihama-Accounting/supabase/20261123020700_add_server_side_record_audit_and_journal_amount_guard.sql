do $patch$
declare
  v_definition text;
  v_old text := 'if abs(v_debit-v_credit) > 0.01 then raise exception ''القيد غير متوازن؛ أُلغي الترحيل بالكامل.''; end if;';
  v_new text := 'if abs(v_debit-v_credit) > 0.01 then raise exception ''القيد غير متوازن؛ أُلغي الترحيل بالكامل.''; end if; if v_type=''JV'' and abs(v_debit-v_amount) > 0.01 then raise exception ''مجموع القيد لا يطابق مبلغ السند.''; end if;';
begin
  v_definition := pg_get_functiondef('public.post_voucher(text)'::regprocedure);
  if position(v_old in v_definition)=0 then raise exception 'Expected posting balance guard not found; migration aborted.'; end if;
  execute replace(v_definition,v_old,v_new);
end;
$patch$;

create or replace function private.capture_app_records_audit()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_actor uuid := auth.uid();
  v_collection text;
  v_record_id text;
  v_action text;
  v_details jsonb;
  v_changed_keys jsonb;
begin
  if tg_op='DELETE' then
    v_collection := old.collection; v_record_id := old.record_id;
    v_details := jsonb_build_object('payload_keys',to_jsonb(array(select jsonb_object_keys(old.payload))),'status',old.payload->>'status');
    v_action := 'record_deleted';
  elsif tg_op='INSERT' then
    v_collection := new.collection; v_record_id := new.record_id;
    v_details := jsonb_build_object('payload_keys',to_jsonb(array(select jsonb_object_keys(new.payload))),'status',new.payload->>'status');
    v_action := 'record_created';
  else
    v_collection := new.collection; v_record_id := new.record_id;
    select coalesce(jsonb_agg(k.key),'[]'::jsonb) into v_changed_keys
    from jsonb_object_keys(coalesce(old.payload,'{}'::jsonb) || coalesce(new.payload,'{}'::jsonb)) as k(key)
    where old.payload->k.key is distinct from new.payload->k.key;
    v_details := jsonb_build_object('changed_keys',v_changed_keys,'old_status',old.payload->>'status','new_status',new.payload->>'status');
    v_action := 'record_updated';
  end if;
  if v_actor is not null then
    insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
    values(v_actor,v_action,v_collection,v_record_id,v_details);
  end if;
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$$;
revoke all on function private.capture_app_records_audit() from public,anon,authenticated;
drop trigger if exists app_records_audit_capture on public.app_records;
create trigger app_records_audit_capture after insert or update or delete on public.app_records
for each row execute function private.capture_app_records_audit();
