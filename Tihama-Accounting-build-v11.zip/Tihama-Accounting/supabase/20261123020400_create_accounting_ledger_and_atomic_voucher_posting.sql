create schema if not exists private;

create table if not exists public.ledger_accounts (
  id uuid primary key default gen_random_uuid(),
  account_code text not null unique,
  account_name text not null,
  account_type text not null check (account_type in ('asset','liability','equity','revenue','expense')),
  currency text not null check (currency ~ '^[A-Z]{3}$'),
  is_active boolean not null default true,
  is_cash boolean not null default false,
  category_key text,
  opening_balance numeric(20,2) not null default 0,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  constraint ledger_cash_must_be_asset check (not is_cash or account_type='asset')
);
create index if not exists ledger_accounts_category_idx
  on public.ledger_accounts(category_key, account_type, currency) where is_active;

create table if not exists public.journal_entries (
  id uuid primary key default gen_random_uuid(),
  entry_number bigint generated always as identity unique,
  entry_date date not null,
  description text not null,
  currency text not null check (currency ~ '^[A-Z]{3}$'),
  source_collection text,
  source_record_id text,
  entry_kind text not null default 'standard' check (entry_kind in ('standard','reversal')),
  status text not null default 'posted' check (status in ('posted','reversed')),
  reversal_of uuid unique references public.journal_entries(id),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  reversed_by uuid references auth.users(id),
  reversed_at timestamptz,
  reversal_reason text,
  constraint journal_source_unique unique(source_collection, source_record_id),
  constraint journal_reversal_shape check (
    (entry_kind='standard' and reversal_of is null and source_collection is not null and source_record_id is not null)
    or (entry_kind='reversal' and reversal_of is not null)
  )
);
create index if not exists journal_entries_date_idx on public.journal_entries(entry_date, entry_number);

create table if not exists public.journal_lines (
  id uuid primary key default gen_random_uuid(),
  entry_id uuid not null references public.journal_entries(id),
  line_number integer not null check (line_number > 0),
  account_id uuid not null references public.ledger_accounts(id),
  description text not null default '',
  debit numeric(20,2) not null default 0 check (debit >= 0),
  credit numeric(20,2) not null default 0 check (credit >= 0),
  currency text not null check (currency ~ '^[A-Z]{3}$'),
  created_at timestamptz not null default now(),
  constraint journal_line_single_side check (not (debit > 0 and credit > 0)),
  constraint journal_line_nonzero check (debit > 0 or credit > 0),
  constraint journal_line_number_unique unique(entry_id, line_number)
);
create index if not exists journal_lines_entry_idx on public.journal_lines(entry_id);
create index if not exists journal_lines_account_idx on public.journal_lines(account_id, currency);

create table if not exists private.audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.ledger_accounts enable row level security;
alter table public.journal_entries enable row level security;
alter table public.journal_lines enable row level security;
alter table private.audit_events enable row level security;

drop policy if exists "active members can read ledger accounts" on public.ledger_accounts;
create policy "active members can read ledger accounts" on public.ledger_accounts
for select to authenticated using (public.is_active_app_member());
drop policy if exists "active members can read journal entries" on public.journal_entries;
create policy "active members can read journal entries" on public.journal_entries
for select to authenticated using (public.is_active_app_member());
drop policy if exists "active members can read journal lines" on public.journal_lines;
create policy "active members can read journal lines" on public.journal_lines
for select to authenticated using (public.is_active_app_member());

revoke all on public.ledger_accounts, public.journal_entries, public.journal_lines from anon, authenticated;
grant select on public.ledger_accounts, public.journal_entries, public.journal_lines to authenticated;
revoke all on private.audit_events from public, anon, authenticated;

create or replace function public.post_voucher(p_record_id text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_row public.app_records%rowtype;
  p jsonb;
  v_type text;
  v_currency text;
  v_date date;
  v_amount numeric(20,2);
  v_desc text;
  v_account text;
  v_category text;
  v_from text;
  v_to text;
  v_account_id uuid;
  v_counter_id uuid;
  v_entry_id uuid;
  v_user uuid := auth.uid();
  v_debit numeric(20,2) := 0;
  v_credit numeric(20,2) := 0;
  v_count integer := 0;
  v_line jsonb;
  v_line_account text;
  v_line_currency text;
  v_line_debit numeric(20,2);
  v_line_credit numeric(20,2);
  v_line_no integer := 0;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if not exists (select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then
    raise exception 'اعتماد السندات متاح لمدير النظام فقط.';
  end if;
  select * into v_row from public.app_records where collection='vouchers' and record_id=p_record_id for update;
  if not found then raise exception 'السند غير موجود.'; end if;
  p := v_row.payload;
  if coalesce(p->>'status','draft') <> 'draft' then raise exception 'لا يمكن اعتماد سند إلا إذا كان مسودة.'; end if;
  if exists(select 1 from public.journal_entries j where j.source_collection='vouchers' and j.source_record_id=p_record_id) then
    raise exception 'سبق ترحيل هذا السند؛ مُنع الترحيل المكرر.';
  end if;
  v_type := p->>'type';
  v_currency := p->>'currency';
  v_date := (p->>'date')::date;
  v_amount := round((p->>'amount')::numeric,2);
  v_desc := coalesce(nullif(p->>'description',''), 'ترحيل سند '||p_record_id);
  v_account := nullif(btrim(p->>'account'),'');
  v_category := nullif(btrim(p->>'category'),'');
  v_from := nullif(btrim(p->>'fromAccount'),'');
  v_to := nullif(btrim(p->>'toAccount'),'');
  if v_amount is null or v_amount <= 0 then raise exception 'مبلغ السند غير صالح.'; end if;
  if v_currency is null or v_currency !~ '^[A-Z]{3}$' then raise exception 'عملة السند غير صالحة.'; end if;
  insert into public.journal_entries(entry_date,description,currency,source_collection,source_record_id,created_by)
  values(v_date,v_desc,v_currency,'vouchers',p_record_id,v_user) returning id into v_entry_id;

  if v_type in ('RV','PV') then
    select id into v_account_id from public.ledger_accounts
    where is_active and is_cash and currency=v_currency and (account_code=v_account or account_name=v_account)
    order by account_code limit 1;
    if v_account_id is null then raise exception 'الحساب النقدي غير مربوط بدليل الحسابات أو عملته غير مطابقة: %', v_account; end if;
    if v_category is null then raise exception 'حدد بند الإيراد أو المصروف.'; end if;
    if v_type='RV' then
      select id into v_counter_id from public.ledger_accounts
      where is_active and account_type='revenue' and currency=v_currency and category_key=v_category order by account_code limit 1;
      if v_counter_id is null then raise exception 'لا يوجد حساب إيراد مربوط بالبند: %', v_category; end if;
      insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
      values(v_entry_id,1,v_account_id,v_desc,v_amount,0,v_currency),(v_entry_id,2,v_counter_id,v_desc,0,v_amount,v_currency);
    else
      select id into v_counter_id from public.ledger_accounts
      where is_active and account_type='expense' and currency=v_currency and category_key=v_category order by account_code limit 1;
      if v_counter_id is null then raise exception 'لا يوجد حساب مصروف مربوط بالبند: %', v_category; end if;
      insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
      values(v_entry_id,1,v_counter_id,v_desc,v_amount,0,v_currency),(v_entry_id,2,v_account_id,v_desc,0,v_amount,v_currency);
    end if;
    v_debit := v_amount; v_credit := v_amount; v_count := 2;
  elsif v_type='TR' then
    if v_from is null or v_to is null or v_from=v_to then raise exception 'حسابا التحويل غير صالحين.'; end if;
    select id into v_account_id from public.ledger_accounts where is_active and is_cash and currency=v_currency and (account_code=v_from or account_name=v_from) order by account_code limit 1;
    select id into v_counter_id from public.ledger_accounts where is_active and is_cash and currency=v_currency and (account_code=v_to or account_name=v_to) order by account_code limit 1;
    if v_account_id is null or v_counter_id is null then raise exception 'حسابا التحويل يجب ربطهما بدليل الحسابات وبالعملة نفسها.'; end if;
    insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
    values(v_entry_id,1,v_counter_id,v_desc,v_amount,0,v_currency),(v_entry_id,2,v_account_id,v_desc,0,v_amount,v_currency);
    v_debit := v_amount; v_credit := v_amount; v_count := 2;
  elsif v_type='JV' then
    if jsonb_typeof(p->'lines') <> 'array' or jsonb_array_length(p->'lines') < 2 then raise exception 'القيد اليومي يحتاج إلى سطرين على الأقل.'; end if;
    for v_line in select value from jsonb_array_elements(p->'lines') loop
      v_line_no := v_line_no + 1;
      v_line_account := coalesce(nullif(btrim(v_line->>'account'),''),nullif(btrim(v_line->>'a'),''));
      v_line_currency := coalesce(v_line->>'currency',v_currency);
      v_line_debit := round(coalesce(nullif(v_line->>'debit','')::numeric,nullif(v_line->>'dr','')::numeric,0),2);
      v_line_credit := round(coalesce(nullif(v_line->>'credit','')::numeric,nullif(v_line->>'cr','')::numeric,0),2);
      if v_line_currency <> v_currency then raise exception 'القيد متعدد العملات غير متاح قبل إعداد حسابات فروق العملة.'; end if;
      if v_line_debit < 0 or v_line_credit < 0 or (v_line_debit>0 and v_line_credit>0) or (v_line_debit=0 and v_line_credit=0) then raise exception 'أحد أسطر القيد يحتوي مبالغ غير صالحة.'; end if;
      select id into v_account_id from public.ledger_accounts where is_active and currency=v_currency and (account_code=v_line_account or account_name=v_line_account) order by account_code limit 1;
      if v_account_id is null then raise exception 'الحساب غير مربوط بدليل الحسابات: %',v_line_account; end if;
      insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
      values(v_entry_id,v_line_no,v_account_id,coalesce(v_line->>'description',v_desc),v_line_debit,v_line_credit,v_currency);
      v_debit := v_debit + v_line_debit; v_credit := v_credit + v_line_credit; v_count := v_count + 1;
    end loop;
    if v_count < 2 then raise exception 'القيد اليومي غير مكتمل.'; end if;
  else
    raise exception 'نوع السند لا يدعم الترحيل المحاسبي في هذه المرحلة: %',v_type;
  end if;
  if abs(v_debit-v_credit) > 0.01 then raise exception 'القيد غير متوازن؛ أُلغي الترحيل بالكامل.'; end if;
  update public.app_records set payload=payload || jsonb_build_object('status','approved','approvedAt',now(),'approvedBy',v_user,'journalEntryId',v_entry_id),updated_at=now()
  where collection='vouchers' and record_id=p_record_id;
  insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
  values(v_user,'voucher_posted','voucher',p_record_id,jsonb_build_object('journal_entry_id',v_entry_id,'currency',v_currency,'amount',v_amount));
  return jsonb_build_object('success',true,'journal_entry_id',v_entry_id,'debit',v_debit,'credit',v_credit,'currency',v_currency);
end;
$$;

create or replace function public.reverse_voucher(p_record_id text,p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_row public.app_records%rowtype;
  v_entry public.journal_entries%rowtype;
  v_reversal_id uuid;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'سبب الإلغاء إلزامي.'; end if;
  if not exists(select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then raise exception 'إلغاء السندات متاح لمدير النظام فقط.'; end if;
  select * into v_row from public.app_records where collection='vouchers' and record_id=p_record_id for update;
  if not found then raise exception 'السند غير موجود.'; end if;
  if v_row.payload->>'status' <> 'approved' then raise exception 'يمكن إلغاء السندات المعتمدة فقط.'; end if;
  select * into v_entry from public.journal_entries where source_collection='vouchers' and source_record_id=p_record_id for update;
  if not found then raise exception 'لا يوجد قيد مرحّل لهذا السند.'; end if;
  if v_entry.status <> 'posted' then raise exception 'سبق عكس هذا القيد.'; end if;
  insert into public.journal_entries(entry_date,description,currency,entry_kind,status,reversal_of,created_by)
  values((now() at time zone 'utc')::date,'قيد عكسي للسند '||p_record_id||' - '||btrim(p_reason),v_entry.currency,'reversal','posted',v_entry.id,v_user)
  returning id into v_reversal_id;
  insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
  select v_reversal_id,row_number() over(order by line_number)::integer,account_id,'عكس: '||description,credit,debit,currency
  from public.journal_lines where entry_id=v_entry.id;
  update public.journal_entries set status='reversed',reversed_by=v_user,reversed_at=now(),reversal_reason=btrim(p_reason) where id=v_entry.id;
  update public.app_records set payload=payload || jsonb_build_object('status','cancelled','cancelledAt',now(),'cancelledBy',v_user,'cancellationReason',btrim(p_reason),'reversalEntryId',v_reversal_id),updated_at=now()
  where collection='vouchers' and record_id=p_record_id;
  insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
  values(v_user,'voucher_reversed','voucher',p_record_id,jsonb_build_object('reason',btrim(p_reason),'reversal_entry_id',v_reversal_id,'original_entry_id',v_entry.id));
  return jsonb_build_object('success',true,'reversal_entry_id',v_reversal_id,'original_entry_id',v_entry.id);
end;
$$;

revoke all on function public.post_voucher(text) from public,anon;
revoke all on function public.reverse_voucher(text,text) from public,anon;
grant execute on function public.post_voucher(text) to authenticated;
grant execute on function public.reverse_voucher(text,text) to authenticated;

