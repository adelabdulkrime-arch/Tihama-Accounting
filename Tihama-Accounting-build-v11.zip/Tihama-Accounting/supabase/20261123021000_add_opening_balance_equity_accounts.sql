insert into public.ledger_accounts(account_code,account_name,account_type,currency,is_cash)
values
  ('EQUITY-OPENING-USD','حقوق الملكية - الأرصدة الافتتاحية (دولار)','equity','USD',false),
  ('EQUITY-OPENING-SAR','حقوق الملكية - الأرصدة الافتتاحية (ريال سعودي)','equity','SAR',false),
  ('EQUITY-OPENING-YER','حقوق الملكية - الأرصدة الافتتاحية (ريال يمني)','equity', 'YER',false)
on conflict (account_code) do nothing;
