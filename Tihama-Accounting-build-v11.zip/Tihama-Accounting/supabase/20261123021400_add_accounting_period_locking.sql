create table if not exists public.accounting_periods (
  id uuid primary key default gen_random_uuid(),
  period_start date not null,
  period_end date not null,
  status text not null default 'closed' check (status in ('closed','reopened')),
  close_reason text not null,
  closed_by uuid not null references auth.users(id),
  closed_at timestamptz not null default now(),
  reopened_by uuid references auth.users(id),
  reopened_at timestamptz,
  reopen_reason text,
  created_at timestamptz not null default now(),
  constraint accounting_period_valid_range check (period_start <= period_end),
  constraint accounting_period_reopen_fields check (
    (status = 'closed' and reopened_by is null and reopened_at is null and reopen_reason is null)
    or
    (status = 'reopened' and reopened_by is not null and reopened_at is not null and length(btrim(reopen_reason)) >= 3)
  )
);
create index if not exists accounting_periods_range_idx
  on public.accounting_periods (period_start, period_end) where status='closed';
alter table public.accounting_periods enable row level security;
revoke all on table public.accounting_periods from anon, authenticated;
grant select on table public.accounting_periods to authenticated;
drop policy if exists accounting_periods_active_member_read on public.accounting_periods;
create policy accounting_periods_active_member_read on public.accounting_periods
  for select to authenticated
  using (exists (select 1 from public.app_members m where m.user_id=(select auth.uid()) and m.is_active));

create or replace function private.enforce_open_accounting_period()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform pg_catalog.pg_advisory_xact_lock(731904221, 1);
  if exists (select 1 from public.accounting_periods p
    where p.status='closed' and new.entry_date between p.period_start and p.period_end) then
    raise exception 'الفترة المحاسبية مغلقة؛ لا يمكن ترحيل قيد بتاريخ %.', new.entry_date;
  end if;
  return new;
end;
$$;
revoke all on function private.enforce_open_accounting_period() from public, anon, authenticated;
drop trigger if exists journal_entries_open_period_guard on public.journal_entries;
create trigger journal_entries_open_period_guard before insert on public.journal_entries
  for each row execute function private.enforce_open_accounting_period();

create or replace function public.close_accounting_period(p_start date, p_end date, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_entry uuid; v_id uuid; v_status text;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if not exists (select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then
    raise exception 'إقفال الفترات المحاسبية متاح لمدير النظام فقط.';
  end if;
  if p_start is null or p_end is null or p_start > p_end then raise exception 'نطاق الفترة المحاسبية غير صالح.'; end if;
  if length(coalesce(nullif(btrim(p_reason),''),'')) < 5 then raise exception 'يجب إدخال سبب واضح لإقفال الفترة.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(731904221, 1);
  if exists (select 1 from public.accounting_periods p
    where p.status='closed' and daterange(p.period_start,p.period_end,'[]') && daterange(p_start,p_end,'[]')
      and not (p.period_start=p_start and p.period_end=p_end)) then
    raise exception 'يتداخل نطاق الفترة مع فترة محاسبية مغلقة أخرى.';
  end if;
  if exists (select 1 from public.app_records r where r.collection='vouchers'
    and coalesce(r.payload->>'status','draft')='draft'
    and (r.payload->>'date') ~ '^\d{4}-\d{2}-\d{2}$'
    and (r.payload->>'date')::date between p_start and p_end) then
    raise exception 'توجد سندات مسودة داخل الفترة؛ اعتمدها أو ألغها قبل الإقفال.';
  end if;
  select j.id into v_entry from public.journal_entries j
    left join public.journal_lines l on l.entry_id=j.id
    where j.entry_date between p_start and p_end group by j.id
    having count(l.id)<2 or abs(coalesce(sum(l.debit),0)-coalesce(sum(l.credit),0))>0.01 limit 1;
  if v_entry is not null then raise exception 'تعذر الإقفال: يوجد قيد غير متوازن أو غير مكتمل (%).',v_entry; end if;
  select id,status into v_id,v_status from public.accounting_periods
    where period_start=p_start and period_end=p_end for update;
  if found then
    if v_status='closed' then raise exception 'الفترة مغلقة مسبقاً.'; end if;
    update public.accounting_periods set status='closed',close_reason=btrim(p_reason),closed_by=v_user,closed_at=now(),
      reopened_by=null,reopened_at=null,reopen_reason=null where id=v_id;
  else
    insert into public.accounting_periods(period_start,period_end,status,close_reason,closed_by)
      values(p_start,p_end,'closed',btrim(p_reason),v_user) returning id into v_id;
  end if;
  insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
    values(v_user,'accounting_period_closed','accounting_period',v_id::text,
      jsonb_build_object('period_start',p_start,'period_end',p_end,'reason',btrim(p_reason)));
  return jsonb_build_object('success',true,'period_id',v_id,'period_start',p_start,'period_end',p_end,'status','closed');
end;
$$;

create or replace function public.reopen_accounting_period(p_start date, p_end date, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_id uuid;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if not exists (select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then
    raise exception 'إعادة فتح الفترات المحاسبية متاحة لمدير النظام فقط.';
  end if;
  if p_start is null or p_end is null or p_start > p_end then raise exception 'نطاق الفترة المحاسبية غير صالح.'; end if;
  if length(coalesce(nullif(btrim(p_reason),''),'')) < 5 then raise exception 'يجب إدخال سبب واضح لإعادة فتح الفترة.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(731904221, 1);
  select id into v_id from public.accounting_periods where period_start=p_start and period_end=p_end and status='closed' for update;
  if v_id is null then raise exception 'الفترة المغلقة غير موجودة.'; end if;
  update public.accounting_periods set status='reopened',reopened_by=v_user,reopened_at=now(),reopen_reason=btrim(p_reason) where id=v_id;
  insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
    values(v_user,'accounting_period_reopened','accounting_period',v_id::text,
      jsonb_build_object('period_start',p_start,'period_end',p_end,'reason',btrim(p_reason)));
  return jsonb_build_object('success',true,'period_id',v_id,'status','reopened');
end;
$$;

create or replace function public.reverse_voucher(p_record_id text,p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_row public.app_records%rowtype; v_entry public.journal_entries%rowtype; v_reversal_id uuid;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if nullif(btrim(p_reason),'') is null then raise exception 'سبب الإلغاء إلزامي.'; end if;
  if not exists(select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then raise exception 'إلغاء السندات متاح لمدير النظام فقط.'; end if;
  select * into v_row from public.app_records where collection='vouchers' and record_id=p_record_id for update;
  if not found then raise exception 'السند غير موجود.'; end if;
  if v_row.payload->>'status' <> 'approved' then raise exception 'يمكن إلغاء السندات المعتمدة فقط.'; end if;
  select * into v_entry from public.journal_entries where source_collection='vouchers' and source_record_id=p_record_id for update;
  if not found then raise exception 'لا يوجد قيد مرحّل لهذا السند.'; end if;
  if v_entry.status <> 'posted' then raise exception 'سبق عكس هذا القيد.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(731904221, 1);
  if exists(select 1 from public.accounting_periods p where p.status='closed' and v_entry.entry_date between p.period_start and p.period_end) then
    raise exception 'لا يمكن إلغاء سند يعود إلى فترة محاسبية مغلقة؛ أعد فتح الفترة بموافقة مدير النظام أولاً.';
  end if;
  insert into public.journal_entries(entry_date,description,currency,entry_kind,status,reversal_of,created_by)
    values((now() at time zone 'utc')::date,'قيد عكسي للسند '||p_record_id||' - '||btrim(p_reason),v_entry.currency,'reversal','posted',v_entry.id,v_user)
    returning id into v_reversal_id;
  insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
    select v_reversal_id,row_number() over(order by line_number)::integer,account_id,'عكس: '||description,credit,debit,currency
    from public.journal_lines where entry_id=v_entry.id;
  update public.journal_entries set status='reversed',reversed_by=v_user,reversed_at=now(),reversal_reason=btrim(p_reason) where id=v_entry.id;
  update public.app_records set payload=payload || jsonb_build_object('status','cancelled','cancelledAt',now(),'cancelledBy',v_user,
    'cancellationReason',btrim(p_reason),'reversalEntryId',v_reversal_id),updated_at=now()
    where collection='vouchers' and record_id=p_record_id;
  insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
    values(v_user,'voucher_reversed','voucher',p_record_id,jsonb_build_object('reason',btrim(p_reason),'reversal_entry_id',v_reversal_id,'original_entry_id',v_entry.id));
  return jsonb_build_object('success',true,'reversal_entry_id',v_reversal_id,'original_entry_id',v_entry.id);
end;
$$;

revoke all on function public.close_accounting_period(date,date,text) from public,anon;
revoke all on function public.reopen_accounting_period(date,date,text) from public,anon;
revoke all on function public.reverse_voucher(text,text) from public,anon;
grant execute on function public.close_accounting_period(date,date,text) to authenticated;
grant execute on function public.reopen_accounting_period(date,date,text) to authenticated;
grant execute on function public.reverse_voucher(text,text) to authenticated;
