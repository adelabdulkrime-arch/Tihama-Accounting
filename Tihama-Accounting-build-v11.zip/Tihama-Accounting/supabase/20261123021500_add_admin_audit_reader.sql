create or replace function public.get_audit_events(p_limit integer default 50, p_offset integer default 0)
returns table (
  id uuid, actor_id uuid, actor_name text, action text, entity_type text,
  entity_id text, details jsonb, created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if not exists (select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then
    raise exception 'سجل المراجعة متاح لمدير النظام فقط.';
  end if;
  if p_limit is null or p_limit < 1 or p_limit > 100 then raise exception 'حجم الصفحة يجب أن يكون بين 1 و100.'; end if;
  if p_offset is null or p_offset < 0 or p_offset > 1000000 then raise exception 'رقم الصفحة غير صالح.'; end if;
  return query
    select e.id,e.actor_id,coalesce(m.display_name,'مستخدم النظام'),e.action,e.entity_type,e.entity_id,
      case when jsonb_typeof(e.details)='object' then e.details else '{}'::jsonb end,e.created_at
    from private.audit_events e
    left join public.app_members m on m.user_id=e.actor_id
    order by e.created_at desc,e.id desc limit p_limit offset p_offset;
end;
$$;
revoke all on function public.get_audit_events(integer,integer) from public,anon;
grant execute on function public.get_audit_events(integer,integer) to authenticated;
