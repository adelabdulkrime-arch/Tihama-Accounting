alter table public.journal_entries drop constraint if exists journal_entries_entry_kind_check;
alter table public.journal_entries add constraint journal_entries_entry_kind_check
check (entry_kind = any (array['standard'::text,'reversal'::text,'opening'::text]));

alter table public.journal_entries drop constraint if exists journal_reversal_shape;
alter table public.journal_entries add constraint journal_reversal_shape
check (
  (entry_kind = 'standard' and reversal_of is null and source_collection is not null and source_record_id is not null)
  or (entry_kind = 'opening' and reversal_of is null and source_collection = 'opening_balances' and source_record_id is not null)
  or (entry_kind = 'reversal' and reversal_of is not null)
);
