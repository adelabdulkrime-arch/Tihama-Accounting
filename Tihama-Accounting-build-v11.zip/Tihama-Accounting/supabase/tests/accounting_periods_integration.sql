-- Rollback-only integration test for accounting-period controls.
-- Before running, replace the all-zero UUID with a dedicated test administrator UUID.
begin;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000000',true);
set local role authenticated;
select public.close_accounting_period('2099-01-01','2099-12-31','اختبار آلي لإقفال الفترة');
reset role;
do $$
declare blocked boolean := false;
begin
  begin
    insert into public.journal_entries(entry_date,description,currency,source_collection,source_record_id,created_by)
    values('2099-06-01','اختبار حارس الفترة','USD','period_test','period-test-closed','00000000-0000-0000-0000-000000000000');
  exception when others then
    if sqlerrm like '%الفترة المحاسبية مغلقة%' then blocked := true; else raise; end if;
  end;
  if not blocked then raise exception 'Period guard did not block insertion'; end if;
end $$;
set local role authenticated;
select public.reopen_accounting_period('2099-01-01','2099-12-31','اختبار آلي لإعادة فتح الفترة');
reset role;
insert into public.journal_entries(entry_date,description,currency,source_collection,source_record_id,created_by)
values('2099-06-01','اختبار بعد إعادة الفتح','USD','period_test','period-test-reopened','00000000-0000-0000-0000-000000000000');
rollback;
