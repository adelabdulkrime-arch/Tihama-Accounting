create or replace function public.create_ledger_account(
  p_account_code text,p_account_name text,p_account_type text,p_currency text,
  p_is_cash boolean default false,p_category_key text default null
)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_id uuid;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if not exists(select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then
    raise exception 'إضافة الحسابات متاحة لمدير النظام فقط.';
  end if;
  if nullif(btrim(p_account_code),'') is null or nullif(btrim(p_account_name),'') is null then raise exception 'رمز الحساب واسمه مطلوبان.'; end if;
  if p_account_type not in ('asset','liability','equity','revenue','expense') then raise exception 'نوع الحساب غير صالح.'; end if;
  if p_currency !~ '^[A-Z]{3}$' then raise exception 'رمز العملة غير صالح.'; end if;
  if p_is_cash and p_account_type <> 'asset' then raise exception 'حسابات النقدية يجب أن تكون من الأصول.'; end if;
  if p_account_type in ('revenue','expense') and nullif(btrim(p_category_key),'') is null then raise exception 'اربط حساب الإيراد أو المصروف ببند محدد.'; end if;
  insert into public.ledger_accounts(account_code,account_name,account_type,currency,is_cash,category_key,created_by)
  values(btrim(p_account_code),btrim(p_account_name),p_account_type,p_currency,p_is_cash,nullif(btrim(p_category_key),''),v_user)
  returning id into v_id;
  insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
  values(v_user,'ledger_account_created','ledger_account',v_id::text,jsonb_build_object('code',btrim(p_account_code),'name',btrim(p_account_name),'type',p_account_type,'currency',p_currency,'category_key',p_category_key));
  return v_id;
end;
$$;
revoke all on function public.create_ledger_account(text,text,text,text,boolean,text) from public,anon;
grant execute on function public.create_ledger_account(text,text,text,text,boolean,text) to authenticated;
