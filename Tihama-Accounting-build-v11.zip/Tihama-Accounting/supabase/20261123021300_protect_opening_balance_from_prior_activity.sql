create or replace function public.set_opening_balances(
  p_balances jsonb,
  p_entry_date date,
  p_description text default 'إثبات الأرصدة الافتتاحية'
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_item jsonb;
  v_code text;
  v_amount numeric(20,2);
  v_account public.ledger_accounts%rowtype;
  v_equity_id uuid;
  v_entry_id uuid;
  v_count integer := 0;
  v_results jsonb := '[]'::jsonb;
begin
  if v_user is null then raise exception 'يجب تسجيل الدخول.'; end if;
  if not exists (select 1 from public.app_members m where m.user_id=v_user and m.is_active and m.role='admin') then
    raise exception 'إدخال الأرصدة الافتتاحية متاح لمدير النظام فقط.';
  end if;
  if jsonb_typeof(p_balances) <> 'array' or jsonb_array_length(p_balances) < 1 then raise exception 'أدخل رصيد حساب واحد على الأقل.'; end if;
  if p_entry_date is null then raise exception 'حدد تاريخ الأرصدة الافتتاحية.'; end if;
  if length(coalesce(nullif(btrim(p_description),''),'')) < 3 then raise exception 'أدخل بياناً واضحاً للقيد.'; end if;

  for v_item in select value from jsonb_array_elements(p_balances)
  loop
    v_code := nullif(btrim(v_item->>'account_code'),'');
    v_amount := round((v_item->>'amount')::numeric,2);
    if v_code is null or v_amount is null or v_amount <= 0 then raise exception 'رمز الحساب أو مبلغ الرصيد الافتتاحي غير صالح.'; end if;

    select * into v_account from public.ledger_accounts
    where account_code=v_code and is_active and is_cash and account_type='asset'
    for update;
    if not found then raise exception 'الحساب النقدي غير موجود أو غير نشط: %',v_code; end if;

    if exists (select 1 from public.journal_entries j where j.source_collection='opening_balances' and j.source_record_id=v_code) then
      raise exception 'سبق تسجيل رصيد افتتاحي للحساب %؛ لا يمكن تكراره.',v_code;
    end if;
    if v_account.opening_balance <> 0 or exists (
      select 1 from public.journal_lines l where l.account_id=v_account.id
    ) then
      raise exception 'لا يمكن إدخال رصيد افتتاحي للحساب % بعد تسجيل حركات عليه.',v_code;
    end if;

    select id into v_equity_id from public.ledger_accounts
    where account_code='EQUITY-OPENING-'||v_account.currency and is_active and account_type='equity' and currency=v_account.currency;
    if v_equity_id is null then raise exception 'حساب حقوق الملكية الافتتاحية غير مهيأ لعملة %.',v_account.currency; end if;

    insert into public.journal_entries(entry_date,description,currency,source_collection,source_record_id,entry_kind,status,created_by)
    values(p_entry_date,btrim(p_description)||' - '||v_account.account_name,v_account.currency,'opening_balances',v_code,'opening','posted',v_user)
    returning id into v_entry_id;

    insert into public.journal_lines(entry_id,line_number,account_id,description,debit,credit,currency)
    values
      (v_entry_id,1,v_account.id,'الرصيد الافتتاحي: '||v_account.account_name,v_amount,0,v_account.currency),
      (v_entry_id,2,v_equity_id,'مقابل الرصيد الافتتاحي',0,v_amount,v_account.currency);

    insert into private.audit_events(actor_id,action,entity_type,entity_id,details)
    values(v_user,'opening_balance_posted','ledger_account',v_code,jsonb_build_object('journal_entry_id',v_entry_id,'amount',v_amount,'currency',v_account.currency));

    v_count := v_count+1;
    v_results := v_results||jsonb_build_array(jsonb_build_object('account_code',v_code,'journal_entry_id',v_entry_id,'amount',v_amount,'currency',v_account.currency));
  end loop;
  return jsonb_build_object('success',true,'count',v_count,'accounts',v_results);
end;
$$;
revoke all on function public.set_opening_balances(jsonb,date,text) from public, anon;
grant execute on function public.set_opening_balances(jsonb,date,text) to authenticated;
