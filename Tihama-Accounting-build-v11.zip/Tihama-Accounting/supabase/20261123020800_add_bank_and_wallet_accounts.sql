alter table public.ledger_accounts
  add column if not exists institution_name text,
  add column if not exists external_account_number text,
  add column if not exists alternate_reference text;

-- Bank and wallet account identifiers are intentionally not seeded in source control.
-- Add the organization's real account references privately in the authenticated database.
